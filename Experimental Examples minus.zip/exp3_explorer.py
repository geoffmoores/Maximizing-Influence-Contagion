import sys
import time
import numpy as np
import random as r
import networkx as nx
import scipy as sci
import matplotlib as mpl
import matplotlib.pyplot as plt
import csv
import copy
import igraph as ig
import graph_tool.all as gt
import re
from os import path as ospath
from scipy.sparse import csr_matrix
from scipy.sparse import lil_matrix
from scipy.special import zeta
import pickle
from sklearn.metrics import mutual_info_score
import scipy.stats
import operator
import collections
import traceback
import bisect
import matplotlib.patches as mpatches
import statsmodels.api as sm
# import matplotlib
# import matplotlib.lines as mlines
# import matplotlib.transforms as mtransforms
# import matplotlib.gridspec as gridspec

import simple_GA as sga
import experiment_graph as eg
import graph_greedy as gg
import general_sbm as g_sbm
import heatmap

def main():

  CC = exp_inf_wrapper("CC",{"seed_set":None, "threshold":.10,"mode":2,"c":1.0},trials=5)
  UC = exp_inf_wrapper("UC",{"seed_set":None, "c":.8},trials=5)
  IC = exp_inf_wrapper("IC",{"seed_set":None, "c":.2},trials=5)
  IC_res = exp_inf_wrapper("IC",{"seed_set":None, "c":.2},trials=50)
  LT = exp_inf_wrapper("LT",{"seed_set":None, "r_threshold":.3, "type":"relative"},trials=1)
  EM_IC = exp_inf_wrapper("IC",{"seed_set":None, "innoculated":None, "c":.4},trials=5)
  ADV_LT = exp_inf_wrapper("ADV_LT",{"seed_set":None, "adv_set":None, "r_threshold":.3, "type":"relative"},trials=1)
  ADV_UC = exp_inf_wrapper("ADV_UC",{"seed_set":None, "adv_set":None, "c":.8},trials=5)

  # ## GRAPH GENERATION ##
  
  graphs_per_type = 5
  graph_types = ["ER","BA","SBM"] # 
  er_degs = [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
  ba_degs = [1.0, 1.25, 1.5, 1.75, 2.0, 2.25, 2.5]
  
  sbm_keys = [] 
  for avg_intra in [.5,1.0,2.0]:
    for avg_inter in [.5,1.0,2.0]:
      if avg_intra == avg_inter:
        continue
      sbm_keys.append((avg_intra,avg_inter))
      
  param_by_type = {"ER":er_degs,"BA":ba_degs,"SBM":sbm_keys}
  
  # if ospath.exists("all_graphs_P1.p"):
    # with open("all_graphs_P1.p","rb") as f:
      # all_graphs = pickle.load(f)
  # else:
    # print("P1 graphs not found.")
      
  results_filename = "results_EXP3_P1.p"
  
  ## RWN HYBRID RESULTS ##
  # algs = ["sbm_ga_greed","info_ga_greed","greedy","rand","top_k"]
  # process="S_LT"
  # rwn_summary_chart(algs,process)

  # process="LT"
  # rwn_summary_chart(algs,process)
  
  # if ospath.exists(results_filename):
    # with open(results_filename,"rb") as f:
      # results = pickle.load(f)
  # else:
    # print("Results not found.")
      
  # process_params = [.1,.2,.3,.4,.5,.6,.7]
  # algs = ["greedy","GA","top_deg","rand"] # "rand","greedy",
  # key_finals = [5,10,"t","evals"]
  # ks = [5,10]
  # IC_trials = 5
  
  # ## ["IC",p_param,g_type,g_param,"greedy",10] # "t","evals"

  # heatmap_results = {}
  # for process in ["IC","LT"]:
    
    # fig, subplots = plt.subplots(2,3)
    # col = -1
    
    # for g_type in graph_types:
      # col += 1
      
      # heatmap_results[process,g_type,"spread"] = np.zeros((7,len(param_by_type[g_type])))
      # heatmap_results[process,g_type,"best"] = np.zeros((7,len(param_by_type[g_type])))
      # x = -1
      # for g_param in param_by_type[g_type]:
        # x += 1
        # y = len(param_by_type[g_type])
        # for p_param in process_params:
          # y -= 1
          # min = 501
          # max = 0
          # for alg in algs:
            # this_keys = []
            # for kf in key_finals: 
              # this_keys.append((process,p_param,g_type,g_param,alg,kf))
            # res = (results[this_keys[0]] + results[this_keys[1]])/2
            # if res < min:
              # min = res
            # if res > max:
              # max = res
              # max_alg = algs.index(alg)
              
          # heatmap_results[process,g_type,"spread"][y,x] = max-min
          # heatmap_results[process,g_type,"best"][y,x] = max_alg
          
      # print("****",process,g_type,"***")
      # print(np.around(heatmap_results[process,g_type,"spread"],1))
      # print(np.around(heatmap_results[process,g_type,"best"],1))
      # row_labels = [i for i in reversed(param_by_type[g_type])]
      # col_labels = process_params

      # cblab = "Solution Quality Spread"

      # title = cblab + ": " + process + ", " + g_type

      # heatmap.heatmap(heatmap_results[process,g_type,"spread"],row_labels,col_labels,x_title="Process Parameter",
        # y_title="Graph Parameter",title=title,cbarlabel=cblab,ax=subplots[0,col])

      # cblab = "Best Algorithm"

      # title = cblab + ": " + process + ", " + g_type
      # heatmap.category_map(heatmap_results[process,g_type,"best"],row_labels,col_labels,algs,x_title="Process Parameter",
        # y_title="Graph Parameter",title=title,cbarlabel=cblab,ax=subplots[1,col])
    
    
    # plt.subplots_adjust(wspace=.25, hspace=.35)
    # plt.show()
      
   ## ALL GRAPHS P2 ##
  
  if ospath.exists("all_graphs_P2.p"):
    with open("all_graphs_P2.p","rb") as f:
      all_graphs = pickle.load(f)

  else:
    print("error, no graphs found")      
      
    ## IC ##
  results_filename = "results_exp2_p2_IC.p" #results_EXP3_P2_IC
  
  if ospath.exists(results_filename):
    with open(results_filename,"rb") as f:
      results = pickle.load(f)
  else:
    print("Results not found, p2 IC")
      
  process_params = [.2, .4, .6, .8]
  ks = [2,4,6,8,10,12,14]
  sizes_index = {500:0, 1000:1, 2000:2}
  pname = "IC"

  algs = ["greedy","GA","GA_P","sbm_gaP_greed","info_gaP_greed","top_k","rand"]
  alg_names = ["Greedy","GA","Scaled GA","(SBM,GA,Greed)","(Info,GA,Greed)","Top K","Rand"]
  summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title="LT_Total_Part",alg_names=alg_names)
  
  #summary_table(pname,results,algs,process_params,ks,all_graphs)
    
    ## LT ##
  results_filename = "results_exp2_p2_LT.p"
  
  # if ospath.exists(results_filename):
    # with open(results_filename,"rb") as f:
      # results = pickle.load(f)
  # else:
    # print("Results not found, p2 LT")
      
  process_params = [0,.333,.666,1.0]
  ks = [2,4,6,8,10,12,14]
  sizes_index = {500:0, 1000:1, 2000:2}
  algs = ["PMBGA","greedy","GA","GA_P","sbm_gaP_greed","info_gaP_greed","top_k","rand"]
  alg_names = ["PMBGA","Greedy","GA","Scaled GA","(SBM,GA,Greed)","(Info,GA,Greed)","Top K","Rand"]
  pname = "LT"
  # summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title="LT_Total_Part",alg_names=alg_names)
  
  #summary_table(pname,results,algs,process_params,ks,all_graphs)
  
  
    ## UC ##
  
  results_filename = "results_exp2_p2_UC.p" 
  
  # if ospath.exists(results_filename):
    # with open(results_filename,"rb") as f:
      # results = pickle.load(f)
  # else:
    # print("Results not found, p2 UC")
    
  process_params = [.4,.6,.8,1.0]
  ks = [2,4,6,8,10,12,14]
  sizes_index = {500:0, 1000:1, 2000:2}
  algs = ["greedy","GA","GA_P","top_k","rand"] # 
  alg_names = ["Greedy","GA","Scaled GA","Top K","Rand"]  # 
  pname = "UC"

  # summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title="UC_Total",alg_names=alg_names)
  #summary_table(pname,results,algs,process_params,ks,all_graphs)

    ## CC ##
  results_filename = "results_exp2_p2_CC.p" 
  
  # if ospath.exists(results_filename):
    # with open(results_filename,"rb") as f:
      # results = pickle.load(f)
  # else:
    # print("Results not found, p2 CC")
    
  # if ospath.exists("cc_graphs.p"):
    # with open("cc_graphs.p","rb") as f:
      # cc_graphs = pickle.load(f)
  # else:
    # print("error, no cc graphs found")
      
  process_params = [0,.333,.666,1.0]
  ks = [2,4,6,8,10,12,14]
  sizes_index = {500:0, 1000:1, 2000:2}
  graph_types = ["SBM","DCSBM","RW"]
  
  algs = ["greedy","GA","GA_P","top_k","rand"]
  alg_names = ["Greedy","GA","Scaled GA","Top K","Rand"]
  pname = "CC"
  # cc_summary_chart(pname,results,algs,process_params,ks,sizes_index,cc_graphs,title="CC_Total",alg_names=alg_names)
  #summary_table(pname,results,algs,process_params,ks,cc_graphs)
  
    # EM_IC ##
  results_filename = "results_exp2_p2_EM_IC.p"
  
  # if ospath.exists(results_filename):
    # with open(results_filename,"rb") as f:
      # results = pickle.load(f)
  # else:
    # print("Results not found, p2 EM IC")
      
  process_params = [.25, .5, 1, 2]
  algs = ["greedy","GA","GA_P"]
  ks = [2,4,6,8,10,12,14]
  sizes_index = {500:0, 1000:1, 2000:2}
  algs = ["greedy","GA","GA_P","top_k","rand"]
  alg_names = ["Greedy","GA","Scaled GA","Top K","Rand"]
  pname = "EM_IC"
  # summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title="EM_IC_Total",alg_names=alg_names)
  #summary_table(pname,results,algs,process_params,ks,all_graphs)
    
    ## ADV_LT ##
  results_filename = "results_exp2_p2_ADV_LT.p"
  
  # if ospath.exists(results_filename):
    # with open(results_filename,"rb") as f:
      # results = pickle.load(f)
  # else:
    # print("Results not found, p2 adv lt")
      
  process_params = [0,.333,.666,1.0]
  algs = ["greedy","GA","GA_P","top_k","rand"]
  alg_names = ["Greedy","GA","Scaled GA","Top K","Rand"]
  pname = "ADV_LT"
  # summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title="ADV_LT_Total",alg_names=alg_names)
  #summary_table(pname,results,algs,process_params,ks,all_graphs)
    
    ## ADV_UC ##
  results_filename = "results_exp2_p2_ADV_UC.p"
  
  # if ospath.exists(results_filename):
    # with open(results_filename,"rb") as f:
      # results = pickle.load(f)
  # else:
    # print("Results not found, p2 ADV_UC")
      
  process_params = [.4,.6,.8,1.0]
  ks = [2,4,6,8,10,12,14]
  sizes_index = {500:0, 1000:1, 2000:2}
  algs = ["greedy","GA","GA_P","top_k","rand"]
  alg_names = ["Greedy","GA","Scaled GA","Top K","Rand"]
  pname = "ADV_UC"
  # summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title="ADV_UC_Total",alg_names=alg_names)
  #summary_table(pname,results,algs,process_params,ks,all_graphs)
  
   ## S_LT ##
  results_filename = "results_exp3_S_LT.p" #results_EXP3_P2_IC
  
  # if ospath.exists(results_filename):
    # with open(results_filename,"rb") as f:
      # results = pickle.load(f)
  # else:
    # print("Results not found, p3 S_LT")
      
  process_params = [0,.333,.666,1.0]
  # "GA_L" valid key here too
  algs = ["greedy","GA","GA_P","top_k","rand"]
  alg_names = ["Greedy","GA","Scaled GA","Top K","Rand"]
  ks = [2,4,6,8,10,12,14]
  sizes_index = {500:0, 1000:1, 2000:2}
  pname = "S_LT"
  # summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title="S_LT_Total",alg_names=alg_names)
  #summary_table(pname,results,algs,process_params,ks,all_graphs)
  
def summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title='Default',alg_names=None):  

  #plt.subplots(constrained_layout=True)
  fig, subplots = plt.subplots(5,3)

  #fig.suptitle(title, y=.9, fontsize=14)
  
  eval_axis = []
  labels = []
  count = 1
  avg_evals = []
  avg_t = []
  
  abbreviations = {"DCSBM":"DC","SBM":"SBM","RW":"RW","BA":"BA",500:500,1000:"1K",2000:"2K"}
  
  time_algs = algs.copy()
  for no_time in ["top_k","rand"]:
    if no_time in time_algs:
      time_algs.remove(no_time)
  
  for i in range(len(time_algs)):
    alg = time_algs[i]
    avg_evals.append([])
    avg_t.append([])
    for size in [500,1000,2000]:
      for g_type in all_graphs:
        if i == 0:
          eval_axis.append(count)
          labels.append(abbreviations[g_type]+'-'+str(abbreviations[size]))
          count += 1
        avg_evals[i].append(0)
        avg_t[i].append(0)
        num_res = 0
        for g_param in all_graphs[g_type]:
          if g_param[1] != size:
            continue
          for p_param in process_params:
            key = (pname,p_param,g_type,g_param,alg,"evals")
            if key in results:
              if isinstance(results[key],list):
                avg_evals[i][-1] += results[key][0]
              else:
                avg_evals[i][-1] += results[key]
            key = (pname,p_param,g_type,g_param,alg,"t")
            if key in results:
              avg_t[i][-1] += results[key]
              num_res += 1
        if num_res > 0:
          avg_evals[i][-1] /= num_res
          avg_t[i][-1] /= num_res
        
  
  scatter(eval_axis,avg_evals,time_algs,fig_titles=["Avg Evals","",""],
    show=False,legend=False,subplot=subplots[4,0],xlabels=labels)
  scatter(eval_axis,avg_t,time_algs,fig_titles=["Avg Time (s)","",""],
    show=False,legend=False,subplot=subplots[4,1],xlabels=labels)
  plt.sca(subplots[4,0])
  plt.xticks(np.arange(1,len(labels)+1), labels, rotation=90)
  plt.sca(subplots[4,1])
  plt.xticks(np.arange(1,len(labels)+1), labels, rotation=90)
  
  if alg_names != None:
    build_legend_patches(alg_names,subplot=subplots[4,2])
  else:
    build_legend_patches(algs,subplot=subplots[4,2])
  subplots[4,2].axis('off')

  row = 0
  for g_type in all_graphs:
    
    inf_overview = [[],[],[]]
    
    for i in range(len(algs)):
      
      alg = algs[i]
      averages = [[0 for x in range(len(ks))] for q in range(3)]
      for g_param in all_graphs[g_type]:
        s_ind = sizes_index[g_param[1]]
          
        for j in range(len(ks)):
          for p_param in process_params:
            key = (pname,p_param,g_type,g_param,alg,ks[j])
            if key in results:
              averages[s_ind][j] += results[key]
          
      for x in range(3):
        averages[x] = [3 * avg / (len(process_params)*len(all_graphs[g_type])) for avg in averages[x]]
        inf_overview[x].append(averages[x])

    legend = False
    for x in range(3):
      if x == 0:
        y_lab = g_type + "\nAvg Inf"
      else:
        y_lab = ""
      x_lab = ""  
        
      scatter(ks,inf_overview[x],algs,fig_titles=["",x_lab,y_lab],
        show=False,legend=legend,subplot=subplots[row,x])
      plt.sca(subplots[row,x])
      plt.xticks(np.arange(2,ks[-1]+2,2), ks)

    row += 1
    
  #plt.savefig(title+'.png', bbox_inches='tight',dpi=300)
  #fig.tight_layout()
  plt.subplots_adjust(wspace=None, hspace=.2)
  #plt.tight_layout(pad=0, w_pad=0, h_pad=0,rect=(0,0,1,1))
  plt.show()
  

def summary_table(pname,results,algs,process_params,ks,all_graphs):  

  time_algs = algs.copy()
  for no_time in ["top_k","rand"]:
    if no_time in time_algs:
      time_algs.remove(no_time)
    
  rel_t = [[] for i in range(len(time_algs))]
  
  for g_type in all_graphs:
    for g_param in all_graphs[g_type]:
      for p_param in process_params:
        trial_results = []
        for i in range(len(time_algs)):
          alg = time_algs[i]
          key = (pname,p_param,g_type,g_param,alg,"t")
          if key in results:
            trial_results.append(results[key])
          else:
            print("missing",key)
            trail_results.append(1)
        trial_min = min(trial_results)
        for i in range(len(time_algs)):
          rel_t[i].append(trial_results[i] / trial_min)
  
  total_time = [np.average(alg_res) for alg_res in rel_t]

  rel_pow = [[] for i in range(len(algs))]
        
  for g_type in all_graphs:
    for g_param in all_graphs[g_type]:
      for k in ks:
        for p_param in process_params:
          trial_results = []
          for i in range(len(algs)):
            alg = algs[i]
            key = (pname,p_param,g_type,g_param,alg,k)
            if key in results:
              trial_results.append(results[key])
            else:
              trial_results.append(0)
          trial_max = max(trial_results)
          for i in range(len(algs)):
            if trial_max == 0:
              rel_pow[i].append(1)
            else:  
              rel_pow[i].append(trial_results[i] / trial_max)
          
  total_pow = [np.average(alg_res) for alg_res in rel_pow]
  
  print(pname)
  for i in range(len(time_algs)):
    print(algs[i])  
  for i in range(len(time_algs)):
    print(total_time[i])
    
  for i in range(len(algs)):
    print(algs[i])
  for i in range(len(algs)):
    print(total_pow[i])


  
def partial_summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title='Default',alg_names=None):  

  #plt.subplots(constrained_layout=True)
  fig, subplots = plt.subplots(5,3)

  #fig.suptitle(title, y=.9, fontsize=14)
  
  eval_axis = []
  labels = []
  count = 1
  avg_evals = []
  avg_t = []
  
  abbreviations = {"DCSBM":"DC","SBM":"SBM","RW":"RW","BA":"BA",500:500,1000:"1K",2000:"2K"}
  
  time_algs = algs.copy()
  for no_time in ["top_k","rand"]:
    if no_time in time_algs:
      time_algs.remove(no_time)
  
  for i in range(len(time_algs)):
    alg = time_algs[i]
    avg_evals.append([])
    avg_t.append([])
    for size in [500,1000,2000]:
      for g_type in all_graphs:
        if i == 0:
          eval_axis.append(count)
          labels.append(abbreviations[g_type]+'-'+str(abbreviations[size]))
          count += 1
        avg_evals[i].append(0)
        avg_t[i].append(0)
        num_res = 0
        for g_param in all_graphs[g_type]:
          if g_param[1] != size:
            continue
          for p_param in process_params:
            pkey = (pname,p_param,g_type,g_param,time_algs[0],"evals")
            if pkey not in results:
              continue
              
            key = (pname,p_param,g_type,g_param,alg,"evals")
            if key in results:
              if isinstance(results[key],list):
                avg_evals[i][-1] += results[key][0]
              else:
                avg_evals[i][-1] += results[key]
            key = (pname,p_param,g_type,g_param,alg,"t")
            if key in results:
              avg_t[i][-1] += results[key]
              num_res += 1
        if num_res > 0:
          avg_evals[i][-1] /= num_res
          avg_t[i][-1] /= num_res
        
  
  scatter(eval_axis,avg_evals,time_algs,fig_titles=["Avg Evals","",""],
    show=False,legend=False,subplot=subplots[4,0],xlabels=labels)
  scatter(eval_axis,avg_t,time_algs,fig_titles=["Avg Time (s)","",""],
    show=False,legend=False,subplot=subplots[4,1],xlabels=labels)
  plt.sca(subplots[4,0])
  plt.xticks(np.arange(1,len(labels)+1), labels, rotation=90)
  plt.sca(subplots[4,1])
  plt.xticks(np.arange(1,len(labels)+1), labels, rotation=90)
  
  if alg_names != None:
    build_legend_patches(alg_names,subplot=subplots[4,2])
  else:
    build_legend_patches(algs,subplot=subplots[4,2])
  subplots[4,2].axis('off')

  row = 0
  for g_type in all_graphs:
    
    inf_overview = [[],[],[]]
    
    for i in range(len(algs)):
      
      alg = algs[i]
      averages = [[0 for x in range(len(ks))] for q in range(3)]
      for g_param in all_graphs[g_type]:
        s_ind = sizes_index[g_param[1]]
          
        for j in range(len(ks)):
          for p_param in process_params:
            pkey = (pname,p_param,g_type,g_param,algs[0],"evals")
            if pkey not in results:
              continue
            key = (pname,p_param,g_type,g_param,alg,ks[j])
            if key in results:
              averages[s_ind][j] += results[key]
          
      for x in range(3):
        averages[x] = [3 * avg / (len(process_params)*len(all_graphs[g_type])) for avg in averages[x]]
        inf_overview[x].append(averages[x])

    legend = False
    for x in range(3):
      if x == 0:
        y_lab = g_type + "\nAvg Inf"
      else:
        y_lab = ""
      x_lab = ""  
        
      scatter(ks,inf_overview[x],algs,fig_titles=["",x_lab,y_lab],
        show=False,legend=legend,subplot=subplots[row,x])
      plt.sca(subplots[row,x])
      plt.xticks(np.arange(2,ks[-1]+2,2), ks)

    row += 1
    
  #plt.savefig(title+'.png', bbox_inches='tight',dpi=300)
  #fig.tight_layout()
  plt.subplots_adjust(wspace=None, hspace=.2)
  #plt.tight_layout(pad=0, w_pad=0, h_pad=0,rect=(0,0,1,1))
  plt.show()
  
def cc_summary_chart(pname,results,algs,process_params,ks,sizes_index,all_graphs,title='Default',alg_names=None):  

  #plt.subplots(constrained_layout=True)
  fig, subplots = plt.subplots(4,3)

  #fig.suptitle(title, y=.9, fontsize=14)
  
  eval_axis = []
  labels = []
  count = 1
  avg_evals = []
  avg_t = []
  
  abbreviations = {"DCSBM":"DC","SBM":"SBM","RW":"RW","BA":"BA",500:500,1000:"1K",2000:"2K"}
  
  time_algs = algs.copy()
  for no_time in ["top_k","rand"]:
    if no_time in time_algs:
      time_algs.remove(no_time)
  
  for i in range(len(time_algs)):
    alg = time_algs[i]
    avg_evals.append([])
    avg_t.append([])
    for size in [500,1000,2000]:
      for g_type in all_graphs:
        if i == 0:
          eval_axis.append(count)
          labels.append(abbreviations[g_type]+'-'+str(abbreviations[size]))
          count += 1
        avg_evals[i].append(0)
        avg_t[i].append(0)
        num_res = 0
        for g_param in all_graphs[g_type]:
          if g_param != size:
            continue
          for p_param in process_params:
            key = (pname,p_param,g_type,g_param,alg,"evals")
            avg_evals[i][-1] += results[key]
            key = (pname,p_param,g_type,g_param,alg,"t")
            avg_t[i][-1] += results[key]
            num_res += 1
        avg_evals[i][-1] /= num_res
        avg_t[i][-1] /= num_res
        
  
  scatter(eval_axis,avg_evals,time_algs,fig_titles=["Avg Evals","",""],
    show=False,legend=False,subplot=subplots[3,0],xlabels=labels)
  scatter(eval_axis,avg_t,time_algs,fig_titles=["Avg Time (s)","",""],
    show=False,legend=False,subplot=subplots[3,1],xlabels=labels)
  plt.sca(subplots[3,0])
  plt.xticks(np.arange(1,len(labels)+1), labels, rotation=90)
  plt.sca(subplots[3,1])
  plt.xticks(np.arange(1,len(labels)+1), labels, rotation=90)
  
  if alg_names != None:
    build_legend_patches(alg_names,subplot=subplots[3,2])
  else:
    build_legend_patches(algs,subplot=subplots[3,2])
  subplots[3,2].axis('off')

  row = 0
  for g_type in all_graphs:
    
    inf_overview = [[],[],[]]
    
    for i in range(len(algs)):
      
      alg = algs[i]
      averages = [[0 for x in range(len(ks))] for q in range(3)]
      for g_param in all_graphs[g_type]:
        s_ind = sizes_index[g_param]
          
        for j in range(len(ks)):
          for p_param in process_params:
            key = (pname,p_param,g_type,g_param,alg,ks[j])
            averages[s_ind][j] += results[key]
          
      for x in range(3):
        averages[x] = [3 * avg / (len(process_params)*len(all_graphs[g_type])) for avg in averages[x]]
        inf_overview[x].append(averages[x])

    legend = False
    for x in range(3):
      if x == 0:
        y_lab = g_type + "\nAvg Inf"
      else:
        y_lab = ""
      x_lab = ""  
        
      scatter(ks,inf_overview[x],algs,fig_titles=["",x_lab,y_lab],
        show=False,legend=legend,subplot=subplots[row,x])
      plt.sca(subplots[row,x])
      plt.xticks(np.arange(2,ks[-1]+2,2), ks)

    row += 1
    
  #plt.savefig(title+'.png', bbox_inches='tight',dpi=300)
  #fig.tight_layout()
  plt.subplots_adjust(wspace=None, hspace=.2)
  #plt.tight_layout(pad=0, w_pad=0, h_pad=0,rect=(0,0,1,1))
  plt.show()
  
def rwn_summary_chart(algs,process,title='Default',alg_names=None):  

  results_filename = "RWN_Hybrid.p" 
  
  ## DONT LOAD ALL GRAPHS, JUST RESULTS ##
  
  if ospath.exists(results_filename):
    with open(results_filename,"rb") as f:
      results = pickle.load(f)
  else:
    print("No results found")
    return None
  
  glist_file = "graphlist.p"
  if ospath.exists(glist_file):
    with open(glist_file,"rb") as f:
      graphlist = pickle.load(f)
  else:
    temp = get_graphlist("names_types")  
    graphlist = []
    for t in temp:
      graph = get_graph(t[2])
      graphlist.append([t[0],t[1],graph.N,graph.results,graph.best_SBM()[1]])

    with open(glist_file,"wb") as f:
      pickle.dump(graphlist, f)
    print("Graphlist stored and built.")
  
  x_axis = []
  count = 0
  infections = [[] for i in range(len(algs))]
  best = []
  
  for graph_item in graphlist:
  
    if graph_item[2] < 500:
      continue
    x_axis.append(count)
    count += 1
    k = min(30,int(graph_item[2]/100))

    for i in range(len(algs)):
      alg = algs[i]
      
      key = (process,graph_item[0],graph_item[1],alg,k)
      if key in results:
        infections[i].append(results[key]/graph_item[2])
      else:
        infections[i].append(np.NaN)
        
  
    best.append(-1)

  best_count = [0 for i in range(len(algs))]
  
  for x in range(len(infections[0])):
    best = [-1,-1]
    for i in range(len(algs)):
      if infections[i][x] > best[0]:
        best = [infections[i][x],i]
    best_count[best[1]] += 1
        
        
  for i in range(len(algs)):
    print(algs[i],best_count[i],round(np.average([x for x in infections[i] if not np.isnan(x)]),3))
        
  # scatter(x_axis,infections,algs,fig_titles=["Infections over all RWN Graphs","Graphs","Infections"],
    # show=False,legend=True,logy=False)
  # plt.show()
  
  fig, subplots = plt.subplots(2,2)
  alg_i = -1
  
  alg_results = [[],[]]
  alg_names = {"sbm_ga_greed":"<SBM,GA,Greedy>","info_ga_greed":"<Infomap,GA,Greedy>"}
  
  for alg in ["sbm_ga_greed","info_ga_greed"]:
    alg_i += 1
    robust = []
    modularity = []
    rel_power = [[],[]]
    plot_results = [[],[],[]]
    
    for graph_item in graphlist:
    
      if graph_item[2] < 500:
        continue

      k = min(30,int(graph_item[2]/100))
  
      alg_key = (process,graph_item[0],graph_item[1],alg,k)
      top_k_key = (process,graph_item[0],graph_item[1],"top_k",k)
      if alg_key in results:
        divisor = results[top_k_key]
        plot_results[0].append(divisor/graph_item[2])
        if divisor == 0:
          divisor = 1
        rel_power[0].append((results[alg_key]-divisor)/graph_item[2])
        plot_results[1].append(results[alg_key]/graph_item[2])
        
        greed_key = (process,graph_item[0],graph_item[1],"greedy",k)
        if greed_key in results:
          divisor = results[greed_key]
          if divisor == 0:
            divisor = 1
          rel_power[1].append((results[alg_key]-divisor)/graph_item[2])
          plot_results[2].append(divisor/graph_item[2])
        else:
          rel_power[1].append(np.NaN)
          plot_results[2].append(np.NaN)
        
        if alg == "sbm_ga_greed":
          r_ind = graph_item[3]["SDAs"].index(graph_item[4])
          robust.append((7-graph_item[3]["robustness"][r_ind])/7)
          mod = graph_item[3][graph_item[4],"modularity"]
          if mod == None:
            mod = 0
            # filename = graph_item[1] + "//" + graph_item[0]
            # graph = get_graph(filename)
            # mod = graph.modularity(None,graph_item[4])
            # print(filename,":",mod)
          modularity.append(mod)
        else:
          r_ind = graph_item[3]["SDAs"].index("infomap")
          robust.append((7-graph_item[3]["robustness"][r_ind])/7)
          mod = graph_item[3]["infomap","modularity"]
          if mod == None:
            mod = 0
            # filename = graph_item[1] + "//" + graph_item[0]
            # graph = get_graph(filename)
            # mod = graph.modularity(None,"infomap")
            # print(filename,":",mod)
          modularity.append(mod)
          
    scatter(robust,rel_power,["Top K","Greedy"],fig_titles=[alg_names[alg],"Robustness","Rel Performance"],
      show=False,legend=False,logy=False,subplot=subplots[alg_i,0],highlight=0,fitline=True)
    
    if None in modularity:
      print(modularity.index(None))
    legend = alg_i == 2
    scatter(modularity,rel_power,["Top K","Greedy"],fig_titles=[alg_names[alg],"Modularity","Rel Performance"],
      show=False,legend=legend,logy=False,subplot=subplots[alg_i,1],highlight=0,fitline=True)
  
    # scatter(robust,plot_results,["Top K","Hybrid","Greedy"],fig_titles=[alg + " Rel Power vs Robust","Robustness","Rel Power"],
      # show=False,legend=False,logy=False,subplot=subplots[alg_i,0])
    
    # legend = alg_i == 1
    # scatter(modularity,plot_results,["Top K","Hybrid","Greedy"],fig_titles=[alg + " Rel Power vs Modularity","Modularity","Rel Power"],
      # show=False,legend=legend,logy=False,subplot=subplots[alg_i,1])
  
  plt.tight_layout()
  plt.show()
  
  # for alg in ["sbm_ga_greed","info_ga_greed"]:
    # robust = []
    # modularity = []
    # rel_power = []
    # for graph_item in graphlist:
      
      
      # if graph_item[2] < 500:
        # continue

      # k = min(30,int(graph_item[2]/100))
      # greed_key = (process,graph_item[0],graph_item[1],"greedy",k)
      
      # alg_key = (process,graph_item[0],graph_item[1],alg,k)

      # if alg_key in results and greed_key in results:
        # divisor = results[greed_key]
        # if divisor == 0:
          # divisor = 1
        # rel_power.append(results[alg_key]/divisor)
        
        # if alg == "sbm_ga_greed":
          # r_ind = graph_item[3]["SDAs"].index(graph_item[4])
          # robust.append((7-graph_item[3]["robustness"][r_ind])/7)
          # modularity.append(graph_item[3][graph_item[4],"modularity"])
        # else:
          # r_ind = graph_item[3]["SDAs"].index("infomap")
          # robust.append((7-graph_item[3]["robustness"][r_ind])/7)
          # modularity.append(graph_item[3]["infomap","modularity"])
          
    # scatter(robust,[rel_power],[alg],fig_titles=[alg + " Rel Power vs Greedy over Robust","Robustness","Rel Power"],
      # show=False,legend=True,logy=False,highlight=1.0)
    # plt.show()
    
    # scatter(modularity,[rel_power],[alg],fig_titles=[alg + " Rel Power vs Greedy over Modularity","Modularity","Rel Power"],
      # show=False,legend=True,logy=False,highlight=1.0)
    # plt.show()



def get_graphlist(graphlist_file):

  path = "graphs//Network_Repository//"
  fh=open(path+graphlist_file+".txt", encoding='utf-8')
  lines = [a.strip() for a in fh.readlines()]
  fh.close()

  count = 0
  total_s = time.time()
  num_graphs = len(lines)
  graphlist = []
  
  for line in lines:
    graph_name, graph_type = line.split()
    filename = graph_type + "//" + graph_name
    graphlist.append([graph_name,graph_type,filename])
    
  return graphlist
    
def get_graph(filename):

  path = "graphs//Network_Repository//"
  try:
    if ospath.exists(path+filename):
      with open(path+filename,'rb') as f:
        graph = pickle.load(f)
    else:
      print("Experiment graph:",filename,"not found.")
  except:
    print("Issue loading",filename)
    print(e)
    
  return graph

def temp_grab(graph,key,fun,params):
  
  if key in graph.temp:
    return graph.temp[key]
    
  store = list(fun(*params))
  seed_set = np.zeros(graph.N)
  seed_set[store] = 1  
    
  graph.temp["key"] = seed_set
  return graph.temp["key"]
  
def exp_inf_wrapper(process,process_params,trials=1):

  def exp_inf(ind,graph):
  
    processes = {"LT":graph.LT, "IC":graph.IC, "UC":graph.UC, "CC":graph.CC,
      "ADV_UC":graph.ADV_UC, "ADV_LT":graph.ADV_LT}
      
    g_process = processes[process]
    
    individual = list(ind)
    
    sum_infected = 0
    seed_set = np.zeros(graph.N)
    seed_set[individual] = 1
    if "innoculated" in process_params:
      process_params["innoculated"] = seed_set
      process_params["seed_set"] = graph.temp["EM_seed"]
    else:  
      if "adv_set" in process_params:
        process_params["adv_set"] = graph.temp["adv_set",process]
      process_params["seed_set"] = seed_set
    
    for x in range(trials):
      sum_infected += g_process(**process_params)[0]
    
    avg_inf = sum_infected / trials
    
    return avg_inf  
    
  return exp_inf
  
def deg(graph,i):
  return np.sum(graph.adj_mat[i])
  
def top_K(graph,fun,k):
  
  dict = {i:fun(graph,i) for i in range(graph.N)}
  sorted_d = sorted(dict, key=dict.get, reverse=True)
  topk = set(sorted_d[0:k])
  return topk
  

def avg_IC(graph,individual,c,trials):

  sum_infected = 0
  seed_set = np.zeros(graph.N)
  seed_set[individual] = 1
  process_params = {"seed_set":seed_set, "c":c}
  for x in range(trials):
    sum_infected += graph.IC(**process_params)[0]
  
  return sum_infected / trials
   
def build_legend_patches(categories,subplot=None,cmap='tab10',size=10):
  cmap = plt.get_cmap(cmap)
  colors = cmap(np.linspace(0, 1, 10))
  patchList = []
  for c in range(len(categories)):
    patch_entry = mpatches.Patch(color=colors[c], label=categories[c])
    patchList.append(patch_entry)
          
  if subplot == None:
    plt.legend(handles=patchList,fontsize=size)
  else:
    subplot.legend(handles=patchList,fontsize=size) #,prop=mpl.font_manager.FontProperties(family='monospace'))


def scatter(x_axis, data, labels, subplot=None, filename=None,fig_titles=["Title","X Axis","Y Axis"],
    cmap="tab10", show=False,logx=False,logy=False, color_points=None,legend=True,bars=[], xlabels=None,
    highlight=np.inf, stacked=False, fitline=False):
  
  if subplot == None:
    fig, subplot = plt.subplots(1)
    
  cmap = plt.get_cmap(cmap)
  colors = cmap(np.linspace(0, 1, 10)) #min(20,len(data))))
  
  markers = [".","*","1","2","+","_","|",",","o","x","v","^"]
  if stacked:
    bottom = [0 for i in range(len(data[0]))]
    for i in range(len(data)):
      
      for y in range(i):
        for x in range(len(data[i])):
          bottom[x] += data[y][x]
          
      subplot.bar(x_axis,data[i],bottom=bottom,color=colors[i],width=1.0,label=labels[i])
  
  else:
    for i in range(len(data)):
      if isinstance(x_axis[0],list) and len(x_axis) == len(data):
        if color_points != None:
          subplot.scatter(x_axis[i],data[i],c=color_points,marker=markers[i],label=labels[i])
        else:
          subplot.scatter(x_axis[i],data[i],c=colors[i],marker=".",label=labels[i])
      else:
        if color_points != None:
          subplot.scatter(x_axis,data[i],c=color_points,marker=markers[i],label=labels[i])
        else:
          highlight_color = np.array(colors[i])
          highlight_color = highlight_color.reshape((1,4))
          xdat = np.array(x_axis)
          dat = np.array(data[i])
          
          subplot.scatter(xdat[dat < highlight],dat[dat < highlight],c=colors[i],marker=".",label=labels[i]) # s=4,
          subplot.scatter(xdat[dat >= highlight],dat[dat >= highlight],c=highlight_color,marker=".",label=labels[i])
  
  if fitline:
    fits = []
    for i in range(len(data)):
      linfit = sm.OLS(data[i],sm.add_constant(x_axis),missing = 'drop').fit()

      fit_sum = "m:"+str(round(linfit.params[1],3))+"\nb:"+str(round(linfit.params[1],2))+"\nR:"+str(round(linfit.rsquared,3))
      
      fits.append(fit_sum)
      
      X_plot = np.linspace(min(x_axis),max(x_axis),100)
      subplot.plot(X_plot, X_plot*linfit.params[1] + linfit.params[0],color=colors[i])  
      
    build_legend_patches(fits,subplot=subplot,size=8)
  
  if legend:
    build_legend_patches(labels,subplot=subplot)
    #subplot.legend(labels,loc='lower right')
    
  for bar in bars:
    y_lim = plt.ylim()
    x_lim = plt.xlim()

    if bar[0] == 'x':
      y = np.linspace(y_lim[0],y_lim[1],100)
      x = [bar[1]]*100
      plt.plot(x, y, '-r')
    else:
      x = np.linspace(x_lim[0],x_lim[1],100)
      y = [bar[1]]*100
      plt.plot(x, y, '-r')
  
  subplot.set_xlabel(fig_titles[1],fontsize=12)
  subplot.set_ylabel(fig_titles[2],fontsize=10)  # 
  subplot.set_title(fig_titles[0],fontsize=10, pad=-10) #
  
  #if xlabels != None:
    #subplot.set_xticks(xlabels) # np.arange(len(xlabels)), 
    #subplot.xticks(rotation=90)
  
  if logx:
    subplot.set_xscale('log')
  if logy:
    subplot.set_yscale('log')
  
  if filename != None:
    plt.savefig(filename + '.png', bbox_inches='tight')
  if show:
    plt.show()

def gen_param_masks(x_keys,param_masks=[]):
  
  if len(x_keys) == 0:
    return param_masks
  top = x_keys[0]
  index = top[0]
  remainder = x_keys[1:]
  new_masks = []
  for kv in top[1:]:
    for param_mask in param_masks:
      new_mask = param_mask.copy()
      new_mask[index] = kv
      new_masks.append(new_mask)

  return gen_param_masks(remainder,new_masks)
  
def get_matching_data(results, pmask):
  
  keys = results.keys()
  matched_data = []
  for key in keys:
    if pmask[2] == "SP" and key[0] == "N":
      pmask[2] = "DP"
    elif pmask[2] == "DP" and key[0] == "K":
      pmask[2] = "SP"
      
    matches = [pmask[i] == key[i] or pmask[i]=="*" for i in range(len(pmask))]
    if False not in matches:
      matched_data.append(results[key])
  return matched_data
  
def add_matching_dict(original, pmask, trimmed_dict):
  
  keys = original.keys()
  for key in keys:
    if pmask[2] == "SP" and key[0] == "N":
      pmask[2] = "DP"
    elif pmask[2] == "DP" and key[0] == "K":
      pmask[2] = "SP"
      
    matches = [pmask[i] == key[i] or pmask[i]=="*" for i in range(len(pmask))]
    if False not in matches:
      trimmed_dict[key] = original[key]
  
def box_whisker(results, y_var, x_keys, base_mask_keys=None, func=None, y_axis="Y Default", title="Default"):

  labels = ["Rep:","Mut:","Cross:","Graph:","Process:","Deg Wtd:","Seed Size:"]

  base_masks = [["*","*","*","*","*","*","*",y_var]]
  pmasks = gen_param_masks(x_keys,param_masks=base_masks)
  
  if base_mask_keys != None:
    trimmed_dict = {}
    base_masks = gen_param_masks(base_mask_keys,base_masks)
    
    for bmask in base_masks:
      add_matching_dict(results,bmask,trimmed_dict)
  else:
    trimmed_dict = results.copy()

  data_sets = []
  for pmask in pmasks:
    data_set = get_matching_data(trimmed_dict,pmask)
    if func != None:
      data_set = [func(datum) for datum in data_set]
    data_sets.append(data_set)
    
  labels = []
  for i in range(len(pmasks)):
    labels.append(pmask_to_label(pmasks[i]))
  
  fig1, ax1 = plt.subplots()
  ax1.set_title(title)
  ax1.boxplot(data_sets,labels=labels)
  plt.xticks(rotation=90)
  ax1.set_ylabel(y_axis)
  plt.tight_layout()
  plt.show()
  
  
def relative_box_whisker(results, y_var, x_keys, base_mask_keys=None, func=None, y_axis="Y Default", title="Default"):

  labels = ["Rep:","Mut:","Cross:","Graph:","Process:","Deg Wtd:","Seed Size:"]

  base_masks = [["*","*","*","*","*","*","*",y_var]]
  pmasks = gen_param_masks(x_keys,param_masks=base_masks)
  
  if base_mask_keys != None:
    trimmed_dict = {}
    base_masks = gen_param_masks(base_mask_keys,base_masks)
    
    for bmask in base_masks:
      add_matching_dict(results,bmask,trimmed_dict)
  else:
    trimmed_dict = results.copy()
    
  data_sets = [[] for i in range(len(pmasks))]
  
  pmask1 = pmasks[0]
  keys_ordered = []
  for key in trimmed_dict:
    if pmask1[2] == "SP" and key[0] == "N":
      pmask1[2] = "DP"
    elif pmask1[2] == "DP" and key[0] == "K":
      pmask1[2] = "SP"
      
    matches = [pmask1[i] == key[i] or pmask1[i]=="*" for i in range(len(pmask1))]
    if False not in matches:
      data_sets[0].append(trimmed_dict[key])
      keys_ordered.append(key)
  
  for i in range(len(pmasks)-1):
    pmask = pmasks[i+1]

    for key in keys_ordered:
      temp_key = list(key)        
      temp_key = [pmask[i] if pmask[i] != "*" else temp_key[i] for i in range(len(pmask))]
      if temp_key[2] == "SP" and temp_key[0] == "N":
        temp_key[2] = "DP"
      elif temp_key[2] == "DP" and temp_key[0] == "K":
        temp_key[2] = "SP"
      temp_key = tuple(temp_key)
      data_sets[i+1].append(trimmed_dict[temp_key])
      
  if func != None:
    for i in range(len(data_sets)):
      data_sets[i] = [func(datum) for datum in data_sets[i]]
  
  data_sets = np.asarray(data_sets)
  data_sets = data_sets.astype(float)
  averages = np.average(data_sets,axis=0)
  data_sets -= averages

  labels = []
  for i in range(len(pmasks)):
    labels.append(pmask_to_label(pmasks[i]))
  
  fig1, ax1 = plt.subplots()
  ax1.set_title(title)
  ax1.boxplot(data_sets.T,labels=labels)
  plt.xticks(rotation=90)
  ax1.set_ylabel(y_axis)
  plt.tight_layout()
  plt.show()
   
def pmask_to_label(pmask):
  
  labels = ["R:","M:","C:","G:","P:","DW:","K:"]
  label = ""
  for i in range(len(pmask)-1):
    if pmask[i] != "*":
      label += labels[i] + str(pmask[i]) + ", "
  return label
        
def time_to_find(fitness_over_time):
  
  best = max(fitness_over_time)
  return np.argwhere(np.array(fitness_over_time) >= best*.99)[0][0]

# GA variant component functions

# N = Size of graph in nodes
# K = num of communities
# a = intra community link probability OR average intra community degree
# b = inter community link probability OR average inter community degree
def gen_sbm(N,K,a,b,probabilities=False):

  am = np.random.uniform(size=(N,N))
  C = int(N/K)
  
  if not probabilities:
    a = a/C
    b = b/(N-C)
 
  for r in range(K):
    for s in range(r+1):
      slice = am[r*C:(r+1)*C,s*C:(s+1)*C]
      if r == s:
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(slice < a, 1.0, 0.0)
      else:
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(slice < b, 1.0, 0.0)
  am = np.tril(am,-1) + np.tril(am,-1).T
  return eg.Experiment_Graph("sbm",am=am)
  
# N = Size of graph in nodes
# K = num of communities
# a = intra community link probability OR average intra community degree
# b = inter community link probability OR average inter community degree
def gen_dc_sbm(N,K,a,b,gamma,kmin,kmax,probabilities=False):

  am = np.random.uniform(size=(N,N))
  C = int(N/K)
  
  if not probabilities:
    a = a/C
    b = b/(N-C)
  
  #print(np.around(am,1))
  
  node_popularities = []
  for r in range(K):
    comm_degs = powerlaw_degrees(gamma,kmin,kmax,C)
    sum_deg = sum(comm_degs)
    node_popularities += [cd/sum_deg for cd in comm_degs]
    #alpha = (a*C)/sum(node_popularities)
  node_popularities = np.array(node_popularities)
  #node_popularities = node_popularities.reshape(1,N)
  #print(node_popularities)
  
  targets = np.outer(node_popularities,node_popularities)
  
  #print(np.around(am,1)) 
  C2 = C**2
 
  for r in range(K):
    for s in range(r+1):
      rand_slice = am[r*C:(r+1)*C,s*C:(s+1)*C]
      target_slice = targets[r*C:(r+1)*C,s*C:(s+1)*C]
      target_sum = np.sum(target_slice)
      if r == s:
        wrs_u = a*C2/target_sum
        target_slice *= wrs_u
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(rand_slice < target_slice, 1.0, 0.0)
      else:
        wrs_u = b*C2/target_sum
        target_slice *= wrs_u
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(rand_slice < target_slice, 1.0, 0.0)
  am = np.tril(am,-1) + np.tril(am,-1).T
  #print(np.around(am,1))
  return eg.Experiment_Graph("sbm",am=am)
  
  
def ba_graph(N,m):
  
  am = np.zeros((N,N))
  link_draw = m
  total = 0
  for n in range(1,N):
    if m%1 != 0.0:
      link_draw = 1 + np.random.poisson(m-1)

    links = int(min(n,link_draw))
    total += links
    probs = np.sum(am,axis=0)[0:n]
    if np.sum(probs) == 0:
      probs = np.ones(n) / n
    else:
      probs = probs / np.sum(probs)
    
    # np.arange non-inclusive,choice is by default non-replacement
    nbrs = np.random.choice(np.arange(n),size=links,replace=False,p=probs)
    # print(n,links,nbrs)

    # if n in nbrs or links != len(nbrs):
      # print("HERE")
    am[n,nbrs] = 1
    am[nbrs,n] = 1
    # print(am)
  
  name = "BA:" + str(N) + "," + str(m)
  new_ba = eg.Experiment_Graph(name,am=am)
  # print(total,np.sum(am))
  return new_ba
    
def check_symmetric(a):
    return np.sum(a - a.T) == 0.0

def sbm_gen_params(N,groups,avg_deg_intra,avg_deg_inter):

  sbm_membership = [int(i/(N/groups)) for i in range(N)]
  inter_edges = avg_deg_inter * (N / groups)
  intra_edges = 2 * avg_deg_intra * (N / groups)
  inter_comm_edges = np.full((groups,groups),inter_edges)
  np.fill_diagonal(inter_comm_edges,intra_edges)
  return [sbm_membership, inter_comm_edges]
  
def powerlaw_degrees(gamma,kmin,kmax,N):
  pdf = np.array([x**-gamma for x in range(kmin,kmax+1)])
  pdf = pdf / np.sum(pdf)
  return np.random.choice(range(kmin,kmax+1),size=N,p=pdf)
  
  
if __name__ == "__main__":
  main()


  # OLD TESTING CODE
  
  # patient_zero = r.randint(0,49)
  # em_seed = list(test_graph.nxgraph.neighbors(patient_zero))
  # em_seed.append(patient_zero)
  # seed_set = np.zeros(test_graph.N)
  # seed_set[em_seed] = 1
  # test_graph.temp["EM_seed"] = seed_set
  # print(temp_grab(test_graph,("adv_set","ADV_UC"),
    # top_K,[test_graph,deg,5]))
  # test_graph.temp["adv_set","ADV_UC"] = temp_grab(test_graph,("adv_set","ADV_UC"),
    # top_K,[test_graph,deg,5])
  # test_graph.temp["adv_set","ADV_LT"] = temp_grab(test_graph,("adv_set","ADV_LT"),
    # top_K,[test_graph,deg,5])
  
  # trials = 5
  # graph_size = 500
  
  # test_graph = gen_dc_sbm(100,5,6,0,2,2,25)
  # g_sbm.label_graph(test_graph.nxgraph,"test",[int(i/20) for i in range(100)])
  # g_sbm.draw_community_graph(test_graph.nxgraph,show=True)
  
  # test_graph2 = gen_dc_sbm(100,2,12,0,2,2,25)
  # g_sbm.label_graph(test_graph2.nxgraph,"second",[int(i/50) for i in range(100)])
  # g_sbm.draw_community_graph(test_graph2.nxgraph,show=True)
  
  # graphs = [test_graph.nxgraph,test_graph2.nxgraph]
  # merged = g_sbm.merge_graphs(graphs)
  # merged = eg.Experiment_Graph("merge",nxgraph = merged)
  # g_sbm.draw_community_graph(merged.nxgraph,show=True)
  

  # s = time.time()
  # tot = 0
  # for i in range(trials):
    # rand = r.sample(range(graph_size),50)
    # tot += CC(rand,test_graph)
  # e = time.time()
  # print("CC ",round(tot/trials,2), round(e-s,2))   

  
  # tot = 0
  # s = time.time()
  # for i in range(trials):
    # res = test_graph.Tang_Seed(10,1,.25,c=.2)
    # tot += IC_res(res[0],test_graph)
  # e = time.time()
  # print("tang ",round(tot/trials,2), round(e-s,2))
  
  # tot = 0
  # s = time.time()  
  # for i in range(trials):
    # res = gg.greedy(test_graph,IC,[10],submodular=True)
    # tot += IC_res(res[0][0],test_graph)
  # e = time.time()
  # print("greedy ",round(tot/trials,2), round(e-s,2))
  
  # for innoculations in range(1,5):
    # s = time.time()
    # tot = 0
    # for i in range(trials):
      # rand = r.sample(range(50),innoculations*5)
      # tot += EM_IC(rand,test_graph)
    # e = time.time()
    # print("EM_IC ",innoculations*5,":",round(tot/trials,2), round(e-s,2))
    
    # s = time.time()
    # tot = 0
    # for i in range(trials):
      # rand = r.sample(range(50),innoculations*5)
      # tot += ADV_LT(rand,test_graph)
    # e = time.time()
    # print("ADV_LT ",innoculations*5,":",round(tot/trials,2), round(e-s,2))
    
    # s = time.time()
    # tot = 0
    # for i in range(trials):
      # rand = r.sample(range(50),innoculations*5)
      # tot += ADV_UC(rand,test_graph)
    # e = time.time()
    # print("ADV_UC ",innoculations*5,":",round(tot/trials,2), round(e-s,2))
  
  # if ospath.exists("test_graph.p"):
    # with open("test_graph.p","rb") as f:
      # test_graph = pickle.load(f)
    # print("loaded")
  # else:
    # print("generated")
    # test_graph = nx.Graph()
    # test_graph.add_nodes_from(range(graph_size))
    # for sbm in sbms:
      # sbm.apply(test_graph)
    
    # test_graph = eg.Experiment_Graph("test",nxgraph = test_graph)
    # test_graph.temp["test_key"] = [1,2,3]
    
    # with open("test_graph.p","wb") as f:
      # pickle.dump(test_graph, f)
  
  # for key in test_graph.temp:
    # print(key,test_graph.temp[key])

  # s = time.time()
  # tot = 0
  # for i in range(trials):
    # rand = r.sample(range(graph_size),50)
    # tot += CC(rand,test_graph)
  # e = time.time()
  # print("CC ",round(tot/trials,2), round(e-s,2))   

  #g_sbm.draw_community_graph(test_graph.nxgraph,show=True)  
  
  # s = time.time()
  # tot = 0
  # for i in range(trials):
    # rand = r.sample(range(graph_size),15)
    # tot += UC(rand,test_graph)
  # e = time.time()
  # print("UC ",round(tot/trials,2), round(e-s,2))
    
  # s = time.time()
  # tot = 0
  # for i in range(trials):
    # rand = r.sample(range(graph_size),15)
    # tot += IC(rand,test_graph)
  # e = time.time()
  # print("IC ",round(tot/trials,2), round(e-s,2))
  
  # s = time.time()
  # tot = 0
  # for i in range(trials):
    # rand = r.sample(range(graph_size),15)
    # rand[0] = 1
    # tot += LT(rand,test_graph)
  # e = time.time()
  # print("LT ",round(tot/trials,2), round(e-s,2))
    
