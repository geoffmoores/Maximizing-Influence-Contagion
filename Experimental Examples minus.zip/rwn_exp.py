import sys
import time
import numpy as np
import random as r
import networkx as nx
import scipy as sci
#import matplotlib as mpl
import matplotlib.pyplot as plt
import copy
import igraph as ig
import graph_tool.all as gt
import re
from os import path as ospath
from scipy.sparse import csr_matrix
from scipy.sparse import lil_matrix
import pickle
from sklearn.metrics import mutual_info_score
import scipy.stats
import traceback
import matplotlib.patches as mpatches
import matplotlib
import matplotlib.lines as mlines
import matplotlib.transforms as mtransforms

#import multi_layer_sbm_recover_3 as mlsbm
#import hetero_deg_sbm as hdsbm
import poisson 
import powerlaw
from experiment_graph import Experiment_Graph
import experiment_graph
import kMeansNew as km

array1 = np.array([[1,2],[0,3]])
array2 = np.array([[3,3],[0,0]])
array3 = np.array([[10,2],[7,3]])
g1 = nx.complete_graph(5)
g2 = nx.wheel_graph(5)

def main():


  SMALL_SIZE = 10
  MEDIUM_SIZE = 10
  BIGGER_SIZE = 12

  plt.rc('font', size=SMALL_SIZE)          # controls default text sizes
  plt.rc('axes', titlesize=SMALL_SIZE)     # fontsize of the axes title
  plt.rc('axes', labelsize=SMALL_SIZE)    # fontsize of the x and y labels
  plt.rc('xtick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
  plt.rc('ytick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
  plt.rc('legend', fontsize=SMALL_SIZE)    # legend fontsize
  plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title
  
  # g1 = nx.planted_partition_graph(4, 32, .375, .04, seed=None, directed=False)
  # g1 = Experiment_Graph("planted partition",nxgraph=g1)
  
  #structure_test(g1,["sbm","dc_sbm","infomap"],reset_robust=True,status=True)
  
  #g2 = load_graph("soc-hamsterster","social")
  #time_test(g2,["sbm","dc_sbm","infomap"])
  
  # g4 = load_graph("econ-poli","econ")
  # structure_test(g4,["sbm","dc_sbm","infomap"],reset_robust=True,status=True)
  # g4.pickle()  
  
  # g3 = load_graph("econ-beause","econ")
  # structure_test(g3,["sbm","dc_sbm","infomap"],reset_robust=True,status=True)
  # g3.pickle()
  
  # structure_test(g1,["infomap"])
  # print(g1.results["VIC_Original"])
  # structure_test(g3,["skip1","skip2","infomap"])
  # print(g3.results["VIC_Original"])
  # print(g1.nxgraph.order(), g1.nxgraph.size(), np.round(g1.results["robustness"][0],3), np.round(g1.results["robustness"][1],3),np.round(g1.results["robustness"][2],3))

  # total_results = {}
  # function_sequentially_from_list("names_types", gather_results, compiler=total_results, save=False)
  # with open("exp1_total.p", 'wb') as fp:
    # pickle.dump(total_results, fp)
  
  if ospath.exists("exp1_total.p"):
    with open("exp1_total.p","rb") as f:
      exp1_total = pickle.load(f)
  
  sizes = []
  avg_deg = []
  robust = [[],[],[]]
  avg_comm_size = [[],[],[]]
  modularity = [[],[],[]]
  poisson_fits = []
  powerlaw_fits = []
  powerlaw_gamma = []
  
  comm_poisson = [[],[],[]]
  comm_plaw = [[],[],[]]
  
  pfits, plawfits = [0,0]
  
  all_graph_stats = []

  SDAs = ["sbm","dc_sbm","infomap"]
  
  all_comm_plaw_gamma = [[],[],[]]
  
  cluster_coeff = []

  graph_types = []
  SDA = "infomap"
  count = 0
  for gname in exp1_total.keys():
    gres = exp1_total[gname]
    if "SDAs" not in gres[0].keys() or SDA not in gres[0]["SDAs"]:
      #print(gname)
      continue
    if gres[0][SDA,"modularity"] == None:#or gres[0][SDA,"modularity"] < .2:
      continue
    # if gres[2] < 150:
      # continue

    graph_types.append(gres[1])
    sizes.append(gres[2])
    avg_deg.append(gres[0]["degree_stats"][0])
    cluster_coeff.append(gres[0]["clustering"][0])
    
    poisson_fits.append(gres[0]["poisson_fit"])
    powerlaw_fits.append(gres[0]["powerlaw_fit"][2])
    powerlaw_gamma.append(gres[0]["powerlaw_fit"][0])
    
    if poisson_fits[-1] > .05:
      pfits += 1
    if powerlaw_fits[-1] > .1 and powerlaw_gamma[-1] >= 2.0 and powerlaw_gamma[-1] <= 3.0:
      plawfits += 1
      print(gname,gres[2])
      
    sbm_ind = gres[0]["SDAs"].index(SDA)
    all_graph_vec = [gres[0][SDA,"modularity"],gres[0]["robustness"][sbm_ind],
      gres[0]["clustering"][0],gres[0]["degree_stats"][0],gres[0][SDA,"avg_comm_size"]]
    if gres[0]["poisson_fit"] > .05:
      all_graph_vec.append(1)
      
    else:
      all_graph_vec.append(0)
    if gres[0]["powerlaw_fit"][2] > .1:
      all_graph_vec.append(gres[0]["powerlaw_fit"][0])
    else:
      all_graph_vec.append(0)
    
    all_graph_vec = [0 if a==None or a == np.NaN or a != a else a for a in all_graph_vec]
    
    all_graph_stats.append(all_graph_vec)

    for SDA in SDAs:
      ind = SDAs.index(SDA)
      if SDA in gres[0]["SDAs"]:
        if SDA == "sbm":
          count += 1
        gind = gres[0]["SDAs"].index(SDA)
        robust[ind].append((7-gres[0]["robustness"][gind])/7)
        avg_comm_size[ind].append(gres[0][SDA,"avg_comm_size"])
        modularity[ind].append(gres[0][SDA,"modularity"])
        
        cpoisson = gres[0][SDA,"poisson_fits"]
        if cpoisson != None:
          comm_poisson[ind].append(cpoisson)
          
        cpower = gres[0][SDA,"plaw_fits"]
        if cpower != None:
          comm_plaw[ind].append(cpower)
         
        all_comm_plaw_gamma[ind] += [e[0] for e in gres[0][SDA,"plaw_gammas"]]
        
      else:
        robust[ind].append(np.NaN)
        avg_comm_size[ind].append(np.NaN)
        modularity[ind].append(np.NaN)

  # print(avg_deg)
  # print(cluster_coeff)

  print(count)
  print(len(graph_types))
  types, nr_counts = np.unique(graph_types, return_counts=True)
  types = list(types)
  for type,count in zip(types,nr_counts):
    print(type,count)
  
  print(len(types))
  type_clusters = [types.index(a) for a in graph_types]
  num_types = len(types)
  
  cmap = plt.get_cmap("tab20c")
  colors = cmap(np.linspace(0, 1, min(20,num_types)))
  if num_types > 20:
    excess = num_types - 20
    extra_colors = plt.get_cmap("tab20b")
    extra_colors = extra_colors(np.linspace(0,1,excess))
    colors = np.vstack((colors,extra_colors))
    
  cluster_colored = [colors[cluster] for cluster in type_clusters]
  
  meta_convert = ['social','biological','biological','biological','social','social','infrastructure','social',
    'social','infrastructure','social','other','other','infrastructure','social','social','infrastructure','infrastructure']

  meta_types = ['social','biological','infrastructure','other']
  meta_map = [meta_convert[types.index(a)] for a in graph_types]
  meta_clusters = [meta_types.index(a) for a in meta_map]
  
  mts, m_counts = np.unique(meta_map, return_counts=True)
  # for mt, mcount in zip(mts, m_counts):
    # print(mt, mcount)
  
  num_types = len(meta_types)
  
  cmap = plt.get_cmap("tab20c")
  meta_colors = cmap(np.linspace(0, 1, min(20,num_types)))
  if num_types > 20:
    excess = num_types - 20
    extra_colors = plt.get_cmap("tab20b")
    extra_colors = extra_colors(np.linspace(0,1,excess))
    meta_colors = np.vstack((meta_colors,extra_colors))
    
  meta_colored = [meta_colors[cluster] for cluster in meta_clusters]
  
  exp2_candidates = {}
  desired_metas = ["social","biological","infrastructure"]
  desired_sizes = [500,1000,2000]
  for size in desired_sizes:
    for type in desired_metas:
      exp2_candidates[size,type] = []
    
  # for gname in exp1_total.keys():
    # gres = exp1_total[gname]

    # type = gres[1]
    # size = gres[2]
    # edges = gres[3]
    # wtd = gres[4]
    # discrete = gres[5]
    
    # if type in types:
      # meta_type = meta_convert[types.index(type)]
    # if meta_type in desired_metas:
      # for dsize in desired_sizes:
        # if abs(dsize-size)/dsize < .35:
          # exp2_candidates[dsize,meta_type].append((gname,type,size,edges,wtd,discrete))
          # continue
    
    # print(gname,type,meta_type,size,edges,wtd,discrete)
    
  # for key in exp2_candidates:
    # print(key,"\n")
    # for candidate in exp2_candidates[key]:
      # print(candidate)
    
  
  # for i in range(len(meta_map)):
    # print(meta_map[i],graph_types[i])
  
  # fig,subplot = plt.subplots(1)
  # build_legend_patches(meta_types,meta_colors)
  # plt.show()
  # plt.savefig('meta_legend.png', bbox_inches='tight')
  
  fig, subplots = plt.subplots(2,2)
  
  scatter(sizes,[avg_deg],["Avg_deg"],fig_titles=["Avg Deg vs Size","Size in Nodes","Avg Deg"],
    logx=True,logy=True,color_points=cluster_colored,legend=False,subplot=subplots[0,0])
    
  scatter(sizes,[avg_deg],["Avg_deg"],fig_titles=["Avg Deg vs Size","Size in Nodes","Avg Deg"],
    logx=True,logy=True,color_points=meta_colored,legend=False,subplot=subplots[0,1])

  scatter(sizes,[cluster_coeff],["Cluster_Coeff"],fig_titles=["Clustering Coefficient vs Size","Size in Nodes","Clustering Coefficient"],
    logx=True,logy=False,color_points=cluster_colored,legend=False,subplot=subplots[1,0])
    
  scatter(sizes,[cluster_coeff],["Cluster_Coeff"],fig_titles=["Clustering Coefficient vs Size","Size in Nodes","Clustering Coefficient"],
    logx=True,logy=False,color_points=meta_colored,legend=False,subplot=subplots[1,1])
  plt.subplots_adjust(wspace=None, hspace=.3)
  #plt.show()
  
  fig, subplots = plt.subplots(2,2)
  
  scatter(sizes,avg_comm_size,SDAs,fig_titles=["Comm Sizes vs Size","Size in Nodes","Avg Comm Size > 50"],
   logx=True,logy=False,color_points=meta_colored,legend=False,subplot=subplots[0,0])
 
  scatter(sizes,avg_comm_size,SDAs,fig_titles=["Comm Sizes vs Size","Size in Nodes","Avg Comm Size > 50"],
   logx=True,logy=False,color_points=cluster_colored,legend=False,subplot=subplots[0,1])
 
  scatter(sizes,modularity,SDAs,fig_titles=["Modularity vs Size","Size in Nodes","Partition Modularity"],
   logx=True,color_points=cluster_colored,legend=False,subplot=subplots[1,0])
    
  scatter(sizes,modularity,SDAs,fig_titles=["Modularity vs Size","Size in Nodes","Partition Modularity"],
   logx=True,color_points=meta_colored,legend=False,subplot=subplots[1,1])
  plt.subplots_adjust(wspace=None, hspace=.3)
  #plt.show()

  # print(len(avg_deg),len(poisson_fits),len(powerlaw_gamma),len(powerlaw_fits))
  # print(pfits)
  # scatter(avg_deg,[poisson_fits],[""],fig_titles=["Poisson GoF vs <k>","Average Degree","Poisson Goodness of Fit"],
   # logx=True,show=True,color_points=cluster_colored,legend=False,filename="Poisson by Deg",bars=[('y',.05)])
 
  # print(plawfits)
  
  fig, subplots = plt.subplots(1,2)
  
  scatter(powerlaw_fits,[powerlaw_gamma],[""],fig_titles=["Powerlaw Gamma vs GoF","Powerlaw Goodness of Fit","Powerlaw Gamma"],
   logx=False,color_points=cluster_colored,legend=False,filename="Gamma by GoF",bars=[('x',.1),('y',2),('y',3)],
   subplot=subplots[0])
   
  scatter(powerlaw_fits,[powerlaw_gamma],[""],fig_titles=["Powerlaw Gamma vs GoF","Powerlaw Goodness of Fit","Powerlaw Gamma"],
   logx=False,color_points=meta_colored,legend=False,filename="Meta Gamma by GoF",bars=[('x',.1),('y',2),('y',3)],
   subplot=subplots[1])

  #plt.show()
  
  # histogram(all_comm_plaw_gamma,labels=SDAs,filename="All Comms Gammas",show=True,
    # fig_titles=["Intragraph Communities Powerlaw Distribution","Powerlaw Gamma","Number of Intragraph Communities"])
  
  # histogram(comm_poisson,labels=SDAs,filename="Comms Proportion Poisson Fits",show=True,
    # fig_titles=["Poisson: Fraction of Fit Communities (for each Graph)","Fraction Comms Fit by Poisson","Number of Real World Networks"])
  # histogram(comm_plaw,labels=SDAs,filename="Comms Proportion Powerlaw Fits",show=True,
    # fig_titles=["Powerlaw: Fraction of Fit Communities (for each Graph)","Fraction Comms Fit by Powerlaw","Number of Real World Networks"])
   
  fig, sda_plots = plt.subplots(3,2)
  
  for i in range(3):
    row = sda_plots[i]
    scatter(modularity[i],[robust[i]],[SDAs[i]],fig_titles=["Mod. vs Robustness; "+SDAs[i],"Modularity","Robustness"],
     logx=False,show=False,color_points=cluster_colored,legend=False,subplot=row[0]) 
    scatter(sizes,[robust[i]],[SDAs[i]],fig_titles=["Robustness "+SDAs[i],"Size (Nodes)","Robustness"],
     logx=True,show=False,color_points=cluster_colored,legend=False,subplot=row[1]) 
  #plt.tight_layout()
  plt.subplots_adjust(wspace=None, hspace=.4)
  plt.show()
  
  # plt.savefig('EXP_1/Mod Overview SDAs.png', bbox_inches='tight',figsize=(7,10),dpi=300)
  


   
  # print(SDAs)
  
  fig, sda_plots = plt.subplots(3,2)
  fig.tight_layout()
  for i in range(3):
    row = sda_plots[i]
    scatter(modularity[i],[robust[i]],[SDAs[i]],fig_titles=["Mod. vs Robustness; "+SDAs[i],"Modularity","Robustness"],
     logx=False,show=False,color_points=meta_colored,legend=False,subplot=row[0]) 
    scatter(sizes,[robust[i]],[SDAs[i]],fig_titles=["Robustness "+SDAs[i],"Size (Nodes)","Robustness"],
     logx=True,show=False,color_points=meta_colored,legend=False,subplot=row[1]) 
  #plt.tight_layout()
  plt.subplots_adjust(wspace=None, hspace=.4)
  #plt.savefig('EXP_1/Mod Overview SDAs Meta.png', bbox_inches='tight',figsize=(7,10),dpi=300)
  plt.show()
   

  #draw_cluster_visual(np.array([[0,0,0],[1,1,1],[10,10,10]]),np.array([0,0,0,0,0,1,1,1,2]),np.array([0,3,0,3,0,1,4,1,2]),alt_labels=["A","B","C","D","E"])
  # kmeans(all_graph_stats,list(range(2,15)),clusters=[type_clusters,meta_clusters],alt_labels=[types,meta_types],
    # filename="Clustering Large",colors=[colors,meta_colors])

  # calculate degree distributions and community properties
  #function_sequentially_from_list("names_types",calc_features, reload=False, reset_part=False, reset_robust=False, save=True)
  
  # Update class structure if new class variables added
  #function_sequentially_from_list("names_types",update_class, reload=False, reset_part=False, reset_robust=False, save=False)
  
  # expects dataset to be 2D List
  # krange is a List
def kmeans(dataset,krange,clusters=None,tactic=2,normalize=True,alt_labels=None,filename=None,colors=None):

  ds = copy.deepcopy(dataset)
  if normalize:
    ds = km.normalize(ds)

  if clusters != None:
    ground_clusters = np.array(clusters[0])
    ground_clusters.reshape(len(dataset))
    by_mutual_info = True

  tot_distances = []
  mut_infos = []
  rand_muts = []
  all_results = {}
  k_clusters = []
  for k in krange:

    results = km.kMeans(ds,k,tactic=2)

    if by_mutual_info:
      k_clusters = np.squeeze(np.array(results[1][:,0]))
      # k_clusters = k_clusters[:,0].T
      # k_clusters = np.squeeze(np.array(k_clusters))
      I = experiment_graph.I_norm(ground_clusters,k_clusters)
      I2 = 0
      for i in range(10):
        rand_clusters = np.random.choice(np.unique(clusters[0]),size=len(dataset))
        I2 += experiment_graph.I_norm(rand_clusters,k_clusters)
      rand_muts.append(I2/10)
      mut_infos.append(I)

    all_results[k] = [results[0],k_clusters]
    
    tot_distances.append(km.p_results(results,k,tactic,normalize))
    
  if filename != None:
    scatter_file = filename + " Cluster Analysis" 
    
  if by_mutual_info:
    scatter(krange,[tot_distances,mut_infos,rand_muts],["Tot. Mn. Diff","Mut Info","Random Cluster Agreement"],
      fig_titles=["Total Mean Distance by # Clusters", "# Clusters", "Total Mean Distance"],show=True,filename=scatter_file)
  else:
    scatter(krange,[tot_distances,mut_infos],["Tot. Mn. Diff"],fig_titles=
      ["Total Mean Distance by # Clusters", "# Clusters", "Total Mean Distance"],show=True,filename=scatter_file)
  
  k_best = int(input("Choose best K:"))

  pos = None
  if alt_labels != None:
    for i in range(len(alt_labels)):
      if colors != None:
        pass_color = colors[i]
      else:
        pass_color = None
      if len(alt_labels) > 1:
        tag = "_"+str(i)
      else:
        tag = ""
      if filename != None:
        pass_file = filename + tag
      else:
        pass_file = None
        
      pos = draw_cluster_visual(all_results[k_best][0],all_results[k_best][1],alt_clusters=np.array(clusters[i]),
        alt_labels=alt_labels[i],filename=pass_file,colors=pass_color,pos=pos)

  return results

def build_legend_patches(categories,colors):
  patchList = []
  for c in range(len(categories)):
          patch_entry = mpatches.Patch(color=colors[c], label=categories[c])
          patchList.append(patch_entry)

  plt.legend(handles=patchList,loc='center left', bbox_to_anchor=(1, 0.5))  

def draw_cluster_visual(centroids, clusters, alt_clusters, cmap="tab20c", alt_labels=None, filename="test", colors=None, pos=None):
  
  cg = gt.Graph(directed=False)
  cg.add_vertex(len(centroids))
  
  types = np.unique(alt_clusters)
  num_types = len(types)

  pie_fracs = cg.new_vertex_property("vector<double>")
  cluster_size = cg.new_vertex_property("int")
  v_size = cg.new_vertex_property("double")

  avg_size = len(clusters)/len(centroids)
  
  if not isinstance(colors,np.ndarray):
    cmap = plt.get_cmap(cmap)
    colors = cmap(np.linspace(0, 1, min(20,num_types)))
    if num_types > 20:
      excess = num_types - 20
      extra_colors = plt.get_cmap("tab20b")
      extra_colors = extra_colors(np.linspace(0,1,excess))
      colors = np.vstack((colors,extra_colors))
  
  for i in range(len(centroids)):
    ci_size = len(np.argwhere(clusters == i))
    cluster_size[cg.vertex(i)] = ci_size
    v_size[cg.vertex(i)] = np.sqrt(ci_size / avg_size) * 75

    types_in_ci = alt_clusters[np.argwhere(clusters == i).T[0]]
    new_frac = np.zeros(num_types)

    for x in range(len(types)):
      new_frac[x] = len(np.argwhere(types_in_ci == x))/ci_size
    pie_fracs[cg.vertex(i)] = new_frac

    for j in range(i):
      cg.add_edge(cg.vertex(i),cg.vertex(j))
  
  weights = []
  for e in cg.get_edges():
    c1 = centroids[int(e[0])]
    c2 = centroids[int(e[1])]
    distance = km.distEclud(c1,c2)
    weights.append(1/distance)

  ew = cg.new_edge_property("double")
  ew.a = np.array(weights)
  cg.ep['weight'] = ew

  if pos == None:
    pos = gt.fruchterman_reingold_layout(cg,weight=cg.ep['weight'])
  else:
    temp = pos
    pos = cg.new_vertex_property("vector<double>")
    for v in cg.get_vertices():
      pos[v] = temp[v]
    cg.vp['pos'] = pos
      
  plt.switch_backend('cairo')

  fig, ax = plt.subplots()

  # gt.graph_draw(cg,pos=pos, vertex_text_color='black', mplfig=fig, vertex_text=cluster_size, vertex_size=v_size, 
    # vertex_shape="pie", vertex_pie_colors=colors, vertex_pie_fractions=pie_fracs)

  gt.graph_draw(cg,pos=pos, vertex_text_color='black', vertex_text=cluster_size, vertex_size=v_size, edge_pen_width=0.0,
    vertex_shape="pie", vertex_pie_colors=colors, vertex_pie_fractions=pie_fracs)

  #build_legend_patches(alt_labels,colors)
  #fig.patch.set_visible(False)  # allows for transparent backgrounds
  ax.axis('off')
  plt.savefig(filename+".pdf",bbox_inches='tight')

  plt.switch_backend('TkAgg')
  return pos
  

def scatter(x_axis, data, labels, subplot=None, filename=None,fig_titles=["Title","X Axis","Y Axis"],
    cmap="tab10", show=False,logx=False,logy=False, color_points=None,legend=True,bars=[]):
  
  if subplot == None:
    fig, subplot = plt.subplots(1)
  
  markers = [".","*","1","2","+","_","|",",","o","x","v","^"]
  for i in range(len(data)):
    if isinstance(x_axis[0],list) and len(x_axis) == len(data):
      if color_points != None:
        subplot.scatter(x_axis[i],data[i],c=color_points,marker=markers[i],label=labels[i])
      else:
        subplot.scatter(x_axis[i],data[i],marker=".",label=labels[i]) 
    else:
      if color_points != None:
        subplot.scatter(x_axis,data[i],c=color_points,marker=markers[i],label=labels[i])
      else:
        subplot.scatter(x_axis,data[i],marker=".",label=labels[i]) 
        
  if legend:
    plt.legend()
    
  for bar in bars:
    y_lim = subplot.get_ylim()
    x_lim = subplot.get_xlim()

    if bar[0] == 'x':
      y = np.linspace(y_lim[0],y_lim[1],100)
      x = [bar[1]]*100
      subplot.plot(x, y, '-r')
    else:
      x = np.linspace(x_lim[0],x_lim[1],100)
      y = [bar[1]]*100
      subplot.plot(x, y, '-r')
 
      
  subplot.set_xlabel(fig_titles[1])
  subplot.set_ylabel(fig_titles[2])
  subplot.set_title(fig_titles[0])
  
  if logx:
    subplot.set_xscale('log')
  if logy:
    subplot.set_yscale('log')
  
  if filename != None:
    plt.savefig(filename + '.png', bbox_inches='tight')
  if show:
    plt.show()
  
def histogram(data,bins=50,labels=None,subplot=None,filename=None,fig_titles=["Title","X Axis","Y Axis"],
    show=False,legend=True):  
  
  num_bins = bins

  if subplot == None:
    fig, subplot = plt.subplots()
    
  subplot.set_xlabel(fig_titles[1])
  subplot.set_ylabel(fig_titles[2])
  subplot.set_title(fig_titles[0])

  # the histogram of the data
  n, bins, patches = subplot.hist(data, num_bins, density=False, label=labels)
  print(n)
  if legend:
    plt.legend()

  # Tweak spacing to prevent clipping of ylabel
  fig.tight_layout()
  
  if filename != None:
    plt.savefig(filename + '.png', bbox_inches='tight')
  if show:
    plt.show() 
  
def partition_to_comm_lists(partition,min_size=1):
  
  communities = np.unique(partition)
  comm_lists = []
  for community in communities:
    comm = list(np  .argwhere(partition == community).T[0])
    if len(comm) > min_size:
      comm_lists.append(comm)
  return comm_lists
  
def get_csr_neg(cm):
  neg = cm.copy()
  neg.data = np.where(neg.data < 0, -neg.data,0)
  res = csr_matrix(neg)
  res.eliminate_zeros()
  return res
  
def get_csr_pos(cm):
  pos = cm.copy()
  pos.data = np.where(pos.data > 0, pos.data, 0)
  res = csr_matrix(pos)
  res.eliminate_zeros()
  return res

def read_edges(graph_filename):

  fh=open("graphs//Network_Repository//"+graph_filename+".edges", encoding='utf-8')
  lines = [a.strip() for a in fh.readlines()]
  fh.close()
  
  weight_exceptions = ["soc-political-retweet"]
  
  edge_lines = [re.sub(r"[\s,]+", " ", a) for a in lines if a[0] != '%']
  edge_lines = [e.split() for e in edge_lines]
  edge_line_length = len(edge_lines[0])
  
  if graph_filename in weight_exceptions: # For graphs which throw errors for weights and the weights 
    edge_line_length = 2 #  have an unclear / not documented meaning, we will ignore them.
  
  origin = [e[0] for e in edge_lines]
  dest = [e[1] for e in edge_lines]
  
  og_nodes = list(set(origin).union(set(dest)))
  og_indices = {og_nodes[i]:i for i in range(len(og_nodes))}
  
  
  origin = [og_indices[e] for e in origin]
  dest = [og_indices[e] for e in dest]
  
  edges = np.stack((np.array(origin), np.array(dest)))
  
  if edge_line_length >= 3:
    weights = np.array([float(e[2]) for e in edge_lines])
  else:
    weights = np.ones(len(edge_lines))
  
  return edges, weights 
  
def read_graphs_from_list(graphlist_file,reload=False):

  path = "graphs//Network_Repository//"
  fh=open(path+graphlist_file+".txt", encoding='utf-8')
  lines = [a.strip() for a in fh.readlines()]
  fh.close()
  
  graph_list = []

  for line in lines:
    graph_name, graph_type = line.split()
    filename = graph_type + "//" + graph_name
    if ospath.exists(path+filename) and not reload:
      with open(path+filename,'rb') as f:
        graph = pickle.load(f)
      graph.gname = graph_name
      graph_list.append(graph)
    else:
      try:
        graph = Experiment_Graph(graph_type,read_data = read_edges(filename), filename=filename,path=path,gname=graph_name)
        graph_list.append(graph)
      except Exception as e:
        print("Issue with",graph_type,graph_name)
        print(e)
    
  return graph_list
  
def load_graph(graph_name,graph_type,reload=False):
  
  path = "graphs//Network_Repository//"
  filename = graph_type + "//" + graph_name
  if ospath.exists(path+filename) and not reload:
    with open(path+filename,'rb') as f:
      graph = pickle.load(f)
    graph.gname = graph_name
    return graph
  else:
    try:
      graph = Experiment_Graph(graph_type,read_data = read_edges(filename), filename=filename,path=path,gname=graph_name)
      return graph
    except Exception as e:
      print("Issue with",graph_type,graph_name)
      print(e)
      return None
  
def experiment_sequentially_from_list(graphlist_file,reload=False,reset_part=False,reset_robust=False):

  path = "graphs//Network_Repository//"
  fh=open(path+graphlist_file+".txt", encoding='utf-8')
  lines = [a.strip() for a in fh.readlines()]
  fh.close()

  count = 0
  total_s = time.time()
  num_graphs = len(lines)
  for line in lines:
    count += 1
    graph_name, graph_type = line.split()
    filename = graph_type + "//" + graph_name
    if ospath.exists(path+filename) and not reload:
      with open(path+filename,'rb') as f:
        graph = pickle.load(f)
      graph.gname = graph_name
    else:
      try:
        graph = Experiment_Graph(graph_type,read_data = read_edges(filename), filename=filename,path=path,gname=graph_name)
      except Exception as e:
        print("Issue loading",graph_type,graph_name)
        print(e)
        continue
    
    try:
      s = time.time()
      print("Considering graph:",graph_name,graph.nxgraph.order(), graph.nxgraph.size())
      if graph.nxgraph.order() > 4000 or graph.nxgraph.size() > 20000:
        structure_test(graph,["infomap"],reset_part=reset_part,reset_robust=reset_robust,status=True)
        graph.pickle()
          
      e = time.time()
      
      if "robustness" in graph.results:
        rb = graph.results['robustness']
        rb_p = [0,0,0]
        for i in range(len(rb)):
          rb_p[i] = rb[i]
            
        if len(rb) == 1: # this is awful code and needs to be fixed eventually
          rb_p[2] = rb_p[0]
          rb_p[0] = 0
          
        sys.stdout.write("Structure Test {}/{}; Elapsed:{}s This graph:{}s ({},{}), Robustness:SBM:{} DC_SBM:{} INFOMAP:{}\n"
         .format(count, num_graphs, np.round(e-total_s), np.round(e-s,1), graph.nxgraph.order(), graph.nxgraph.size(), 
          np.round(rb_p[0],3), np.round(rb_p[1],3),np.round(rb_p[2],3)))
        sys.stdout.flush()
        
    except Exception as e:
      print("Issue structure test on",graph_type,graph_name)
      print(e)
      continue    
      
def function_sequentially_from_list(graphlist_file,function,compiler=None, reload=False,reset_part=False,reset_robust=False,save=True):

  path = "graphs//Network_Repository//"
  fh=open(path+graphlist_file+".txt", encoding='utf-8')
  lines = [a.strip() for a in fh.readlines()]
  fh.close()

  count = 0
  total_s = time.time()
  num_graphs = len(lines)
  for line in lines:
    count += 1
    graph_name, graph_type = line.split()
    filename = graph_type + "//" + graph_name
    if ospath.exists(path+filename) and not reload:
      print(filename)
      with open(path+filename,'rb') as f:
        graph = pickle.load(f)
      graph.gname = graph_name
    else:
      try:
        graph = Experiment_Graph(graph_type,read_data = read_edges(filename), filename=filename,path=path,gname=graph_name)
      except Exception as e:
        print("Issue loading",graph_type,graph_name)
        print(e)
        continue
    
    try:
      s = time.time()
      print("Considering graph:",graph_name,graph.nxgraph.order(), graph.nxgraph.size())
      if compiler == None:
        function(graph)
      else:
        function(graph,compiler)
      if save:
        graph.pickle()
      e = time.time()
        
      sys.stdout.write("Running function on graph {}/{}; Elapsed:{}s This graph:{}s ({},{})\n"
       .format(count, num_graphs, np.round(e-total_s), np.round(e-s,1), graph.nxgraph.order(), graph.nxgraph.size()))
      sys.stdout.flush()
        
    except Exception as e:
      print("Issue with function on",graph_type,graph_name)
      print(traceback.format_exc())
      continue         
      
def save_dcsbm(graph):
  graph.get_structure("dc_sbm",runs=5,reset=False,add=True)
  
def update_class(graph):
  
  #print(graph.results.keys())
  update_eg = Experiment_Graph(graph.type,am=graph.adj_mat,filename=graph.filename,path=graph.path,gname=graph.gname)
  update_eg.structures = graph.structures
  update_eg.results = graph.results
  update_eg.pickle()
  
def gather_results(graph, total_results):
  
  total_results[graph.gname] = [graph.results, graph.type, graph.N, graph.M, graph.weighted, graph.discrete]
  
  
def calc_features(graph):

  deg_seq = graph.get_deg_seq()
  deg_var = np.var(deg_seq)
  graph.results["degree_stats"] = [graph.M / graph.N, deg_var]
  
  graph.results["poisson_fit"] = poisson.fit(deg_seq)[1]
  graph.results["powerlaw_fit"] = powerlaw.fit(deg_seq)
  
  clustering_coeffs = np.array(list(nx.clustering(graph.nxgraph,weight='weight').values()))
  global_clustering = np.average(clustering_coeffs)
  clustering_var = np.var(clustering_coeffs)
  
  graph.results["clustering"] = [global_clustering, clustering_var]
  
  sdas = [sda for sda in graph.structures.keys()]
  for sda in sdas:
    structure = graph.structures[sda]
    partition = graph.partition(structure,sda)
    communities = partition_to_comm_lists(partition,min_size = 50)
    comm_sizes = [len(comm) for comm in communities]
    num_comms = len(communities)
    
    graph.results[sda,"modularity"] = graph.modularity(structure,sda)
    if num_comms > 0:
      graph.results[sda,"avg_comm_size"] = np.average(comm_sizes)
    else:
      graph.results[sda,"avg_comm_size"] = None
    
    plaw_fits = 0
    poisson_fits = 0
    
    plaw_gamma = []
    plaw_gamma_var = []
    
    for comm in communities:
      comm_subgraph = graph.nxgraph.subgraph(comm)
      comm_deg_seq = np.array([i[1] for i in comm_subgraph.degree()])
      plaw_comm = powerlaw.fit(comm_deg_seq)
      if plaw_comm[2] > .01:
        plaw_fits += 1
        plaw_gamma.append([plaw_comm[0],plaw_comm[1]])
        
      poisson_comm = poisson.fit(comm_deg_seq)
      if poisson_comm[1] > .05:
        poisson_fits += 1
    if num_comms > 0:
      graph.results[sda,"poisson_fits"] = poisson_fits / num_comms
      graph.results[sda,"plaw_fits"] = plaw_fits / num_comms
    else:
      graph.results[sda,"poisson_fits"] = None
      graph.results[sda,"plaw_fits"] = None     
      
    graph.results[sda,"plaw_gammas"] = plaw_gamma
  
  # for key in graph.results:
    # print(key,graph.results[key])
    
  
def structure_test(graph,SDAs,X=5,alphas=[i*.05 for i in range(8)],runs=5,store=True,reset_part=False,reset_robust=False,status=False,save_increments=False):

  if not reset_robust and "robustness" in graph.results:
    return graph.results["robustness"], graph.results["VIC_Original"]
    
  alphas = [round(i,2) for i in alphas]

  VIC_Original = np.zeros((len(SDAs),len(alphas)))
  time_sdas = [0,0,0]
  partitions = {}
  
  t1 = 0
  for SDA in SDAs:
    if SDA == "skip1" or SDA == "skip2":
      continue
    if status:
      sys.stdout.write("\rSDA {}; On Original graph: ({},{}) last in {}s            "
       .format(SDA, graph.nxgraph.order(), graph.nxgraph.size(),t1))
      sys.stdout.flush()
    s = time.time()
    partitions[SDA] = graph.partition(graph.get_structure(SDA,runs=runs,reset=reset_part,add=True),SDA)
    e = time.time()
    t1 = np.round(e-s,2)
    
  graph.pickle()
  
  t1,t2 = [0,0]
  if status:
    print("\nBeginning Perturbations")
  for iteration in range(X):
    for alpha in alphas[1:]:
      # sys.stdout.write("\rIteration {}; On Alpha:{}/{}; Generating config graph ({},{})"
        # .format(iteration,alpha,len(alphas)-1,graph.nxgraph.order(),graph.nxgraph.size()))
      # sys.stdout.flush()
      graph_a = graph.wtd_config_graph(alpha=alpha,ret_Exp_Graph=True)
      if graph_a.gtgraph.num_vertices() != graph.gtgraph.num_vertices():
        print("Generated graph of unequal vertices:",graph.name,graph_a.gtgraph.num_vertices(),graph.num_vertices())
      
      for SDA in SDAs:
        if SDA == "skip1" or SDA == "skip2":
          VIC_Original[SDAs.index(SDA),alphas.index(alpha)] = -1.0
          continue
        if status:
          sys.stdout.write("\rIteration {}; On Alpha:{}/{}; SDA:{} on graph ({},{}) last in {}s,{}s                "
            .format(iteration,alpha,len(alphas)-1,SDA,graph.nxgraph.order(),graph.nxgraph.size(),t1,t2))
          sys.stdout.flush()
        s = time.time()
        partition = graph_a.partition(graph_a.get_structure(SDA,runs=1),SDA)
        e = time.time()
        t1 = np.round(e-s,1)
        s = time.time()
        VIC_Original[SDAs.index(SDA),alphas.index(alpha)] += VIC(partition,partitions[SDA])
        e = time.time()
        t2 = np.round(e-s,1)
        
        
  VIC_Original /= X
  if status:
    print()

  robustness = np.sum(VIC_Original,axis=1)
  
  if store:
    graph.results["VIC_Original"] = VIC_Original
    graph.results["robustness"] = robustness
    graph.results["alphas"] = alphas
    graph.results["SDAs"] = SDAs
    
  return robustness, VIC_Original
  
def time_test(graph,SDAs):

  time_sdas = [0,0,0]
  num_comms = [0,0,0]
  partitions = {}
  
  for SDA in SDAs:

    s = time.time()
    partitions[SDA] = graph.partition(graph.get_structure(SDA,runs=1,reset=True,add=True),SDA)
    e = time.time()
    num_comms[SDAs.index(SDA)] = len(np.unique(partitions[SDA]))
    time_sdas[SDAs.index(SDA)] = np.round(e-s,1)
  
  print(time_sdas)
  print(num_comms)

  config_t = 0
  for x in range(5):
    s = time.time()
    alpha = (x+1)*.05
    graph_a = graph.wtd_config_graph(alpha=alpha,ret_Exp_Graph=True)
    e = time.time()
    config_t += (e-s)
    if graph_a.gtgraph.num_vertices() != graph.gtgraph.num_vertices():
      print("Generated graph of unequal vertices:",graph.name,graph_a.gtgraph.num_vertices(),graph.num_vertices())
  print(np.round(config_t / 5,1))

  s = time.time()
  VIC(partitions[SDAs[0]],partitions[SDAs[1]])
  VIC(partitions[SDAs[1]],partitions[SDAs[2]])
  VIC(partitions[SDAs[2]],partitions[SDAs[0]])
  e = time.time()
  print(np.round((e-s)/3, 1))
       
  
def inspect_robust(graph,SDA,alphas=[i*.05 for i in range(6)],runs=5):

  #VIC_Configs = np.zeros((len(alphas)))
  VIC_Original = np.zeros((len(alphas)))
  partitions = {}
  
  print(graph.nxgraph.order(),graph.nxgraph.size())
  pos = nx.spring_layout(graph.nxgraph)
  fig, plots = plt.subplots(1,len(alphas)+1)
  fig.tight_layout()
  
  # G_ = graph.wtd_config_graph(ret_Exp_Graph=True)
  # partitions[SDA] = G_.partition(G_.get_structure(SDA,runs=runs),SDA)
  # G_.draw_graph_communities(partitions[SDA],pos=pos,subplot=configs[0])

  # for alpha in alphas[1:]:
    # G_a = G_.wtd_config_graph(alpha=alpha,ret_Exp_Graph=True)
    # partition = G_a.partition(G_a.get_structure(SDA,runs=runs),SDA)
    
    # G_a.draw_graph_communities(partition,pos=pos,subplot=configs[alphas.index(alpha)])
    # VIC_Configs[alphas.index(alpha)] += VIC(partition,partitions[SDA])

  # print("\nConfig\n",partitions[SDA])
  
  partitions[SDA] = graph.partition(graph.get_structure(SDA,runs=runs,reset=True,add=True),SDA)
  graph.draw_graph_communities(partitions[SDA],pos=pos,subplot=plots[1])
  # print("\nOriginal\n",partitions[SDA])
  
  for alpha in alphas[1:]:
    graph_a = graph.wtd_config_graph(alpha=alpha,ret_Exp_Graph=True)
    
    ew = graph_a.gtgraph.ep.weight.a
    # print("Non integer edges for mutated graph:")
    # print(graph_a.weighted,graph_a.rec_type)
    # print(ew[(ew != 0.0) & (ew != 1.0)])

    partition = graph_a.partition(graph_a.get_structure(SDA,runs=runs),SDA)
    print("\nPerturbed:",alpha,"best partition:\n",partition)
    
    graph_a.draw_graph_communities(partition,pos=pos,subplot=plots[alphas.index(alpha)+1])
    VIC_Original[alphas.index(alpha)] += VIC(partition,partitions[SDA])
        
  
  np_alphas = np.array(alphas)
  #VIC_Diff = VIC_Configs - VIC_Original
  
  #summary[0].scatter(np_alphas,VIC_Configs,c="black",edgecolors='none',label="CONFIG")
  plots[0].scatter(np_alphas,VIC_Original,c="red",edgecolors='none',label="ORIGINAL")
  
  plt.show()
  
  robustness = np.sum(VIC_Original)
    
  return robustness, VIC_Original #VIC_Configs, VIC_Original, VIC_Diff

  
def test_speed(G,k=5,L=1,runs=1,display=False):

  print("Nodes, edges:",G.order(),G.size())
  print(nx.to_numpy_array(G))
  s = time.time()
  #hdsbm.hetero_deg_SBM_recover(G,k,runs=runs)
  e = time.time()
  print("DC SBM Done in:",e-s)
  s = time.time()
  mlsbm.model_recover(G,L,k,runs=runs,display=display)
  e = time.time()
  print("Multi Daudin Done in:",e-s)
  
def test_multi_sbm(k=50,display=False,printing="min"):
  
  G = nx.Graph()
  g1 = nx.complete_graph(k)
  g2 = nx.complete_graph(k)
  A = nx.disjoint_union(g1,g2)
  second_layer_clique_1 = r.sample(set(A.nodes),k)
  second_layer_clique_2 = set(A.nodes).difference(second_layer_clique_1)
  #second_layer_clique_1 = [0,1,2,3,4,5,6,7,29,28,27,26,25,24,23]
  #second_layer_clique_2 = [8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
  for i in second_layer_clique_1:
    for j in second_layer_clique_1:
      if i != j:
        A.add_edge(i,j)
  for i in second_layer_clique_2:
    for j in second_layer_clique_2:
      if i != j:
        A.add_edge(i,j)
  
  G = A.copy()
  mlsbm.model_recover(G,2,2,runs=5,display=display)
  
def analyze_sparse(in_am,print_whole=True):

  N = in_am.get_shape()[0]
  Deg = in_am.getnnz() # total degree
  Str = in_am.sum() # total strength 
  s_i = np.array(in_am.sum(0))[0] # strength senquence
  d_i = np.array([in_am.getcol(i).getnnz() for i in range(N)])
  
  print(N,Deg,Str)
  print(np.around(s_i,2))
  print(d_i)
  if print_whole:
    print(np.around(in_am.todense(),2))  
  else:
    print(np.around(in_am.data[0:15],2))
    
def get_analyze_sparse(in_am):

  N = in_am.get_shape()[0]
  Deg = in_am.getnnz() # total degree
  Str = in_am.sum() # total strength 
  s_i = np.array(in_am.sum(0))[0] # strength senquence
  d_i = np.array([in_am.getcol(i).getnnz() for i in range(N)])
  
  return Deg, Str, s_i, d_i

main()
