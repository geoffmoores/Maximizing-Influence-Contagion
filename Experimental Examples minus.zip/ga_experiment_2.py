import sys
import time
import numpy as np
import random as r
import networkx as nx
import scipy as sci
import matplotlib as mpl
import matplotlib.pyplot as plt
import csv
import copy
import igraph as ig
import graph_tool.all as gt
import re
from os import path as ospath
from scipy.sparse import csr_matrix
from scipy.sparse import lil_matrix
from scipy.special import zeta
import pickle
from sklearn.metrics import mutual_info_score
import scipy.stats
import operator
import collections
import traceback
import bisect

import simple_GA as sga
import experiment_graph as eg

def main():


  if ospath.exists("results_ga2u.p"):
    with open("results_ga2u.p","rb") as f:
      results_ga2 = pickle.load(f)
  else:
    results_ga2 = {}
  
  representation_keys = ["N","K"]
  mutation_keys = ["R","N","D"]
  crossover_keys = {"N":["DP","NM","DC"],"K":["SP","NM","DC"]}
  graph_keys = ["BA_1","BA_2","SBM","DCSBM","FB2"]
  param_keys = ["IC .1","IC .25","IC .4"]
  
  fitness_functions = {"K":klist_fit_wrapper, "N":nlist_fit_wrapper}
  
  ind_gens = {"K":klist_gen,"N":nlist_gen}
  
  mutation_funcs = {"N":nlist_mutate, "K":klist_mutate}
  mutation_types = {"R":"random","N":"neighbor","D":"distance"}  
  
  crossover_funcs = {"N":n_list_crossover, "K":k_list_crossover}
  crossover_types = {"SP":"single_point","DP":"double_point","NM":"network_mask","DC":"degree_cooperation"}
  
  graph_gens = {"BA_1":ba_test_graph,"BA_2":ba_test_graph,"SBM":gen_sbm,"DCSBM":gen_dc_sbm,"FB2":get_fb_2}
  graph_params = {"BA_1":[500,2],"BA_2":[500,3],"SBM":[500,10,8,2],"DCSBM":[500,10,8,2,2,2,25],"FB2":[]}
  
  LT_params = {"LT .2":{"seed_set":None, "c":.2},"LT .3":{"seed_set":None, "c":.3},"LT .4":{"seed_set":None, "c":.4}}
  IC_params = {"IC .025":{"seed_set":None, "c":.025},"IC .05":{"seed_set":None, "c":.05},"IC .1":{"seed_set":None, "c":.1},"IC .25":{"seed_set":None, "c":.25},"IC .4":{"seed_set":None, "c":.4}}
  
  #('K', 'N', 'SP', 'DCSBM', 'IC .25', False, 5)
  representation = 'K'
  mutation = 'N'
  crossover = 'SP'
  graph = 'DCSBM'
  params = "IC .1"
  deg_wtd = False
  trials = 5
  

  test_graphs = []
  for trial in range(trials):
    test_graphs.append(graph_gens[graph](*graph_params[graph]))
    print(test_graphs[-1].M/test_graphs[-1].N)
  
  ts = time.time()
  e = time.time()
  for pr_m in range(0,11):
    GA_params = {"pr_mutate":(pr_m/10.0),"iterations":100,"pool_size":100,"tournament_size":2}

    for pr_c in range(0,11):
      print("Starting Trials for:",(pr_m/10.0),(pr_c/10.0),"total time:",round(e-ts,1))
      
      for k in [5,10]:
        
        if (params,pr_m,pr_c,k,"sol") in results_ga2:
          continue
        try:
          sol_fit = 0
          elite_progress = np.zeros(GA_params["iterations"]+1)
          avg_fitness = np.zeros(GA_params["iterations"]+1)

          s = time.time()
          for test_graph in test_graphs:

            ga_fitness = fitness_functions[representation](test_graph,10,test_graph.IC,IC_params[params],k)
            ga_mutate = mutation_funcs[representation](test_graph,k,mutate_type=mutation_types[mutation],degree_wtd=deg_wtd)
            ga_crossover = crossover_funcs[representation](test_graph,k,(pr_c/10.0),crossover_type=crossover_types[crossover],degree_wtd=deg_wtd)
            ga_ind_gen = ind_gens[representation](test_graph,k)
            checker = check_k(k)
            trial_ga = sga.GA_generator(ga_fitness, ga_ind_gen, GA_params, mutator = ga_mutate, reproducer = ga_crossover, 
              constraint_checker = checker, status=False, early_stop=False)
            t_sol, fit_evals, t_elite_progress, t_avg_fitness, final_pool = trial_ga()
            
            c = IC_params[params]['c']
            sol_fit += avg_IC(test_graph,t_sol[0],c,20)
            elite_progress += np.array(t_elite_progress)
            avg_fitness += np.array(t_avg_fitness)

          e = time.time()

          sol_fit /= trials
          elite_progress /= trials
          avg_fitness /= trials

          print("Sol @",round(pr_m/10.0,1),round(pr_c/10.0,1),k,"found:",round(sol_fit,2),"in:",round(e-s,1),"s. Total time:",round(e-ts,1))
         
          results_ga2[(params,pr_m,pr_c,k,"sol")] = sol_fit
          results_ga2[(params,pr_m,pr_c,k,"elite_time")] = elite_progress
          results_ga2[(params,pr_m,pr_c,k,"avg_fit")] = avg_fitness
 
          with open("results_ga2u.p","wb") as f:
            pickle.dump(results_ga2, f)

        except Exception as e:
          print("Failed to conduct ga:",(params,pr_m,pr_c,k,"sol"))
          print(traceback.format_exc())
          e = time.time()


def avg_IC(graph,individual,c,trials):

  sum_infected = 0
  seed_set = np.zeros(graph.N)
  seed_set[individual] = 1
  process_params = {"seed_set":seed_set, "c":c}
  for x in range(trials):
    sum_infected += graph.IC(**process_params)[0]
  
  return sum_infected / trials

def gen_param_masks(x_keys,param_masks=[]):
  
  if len(x_keys) == 0:
    return param_masks
  top = x_keys[0]
  index = top[0]
  remainder = x_keys[1:]
  new_masks = []
  for kv in top[1:]:
    for param_mask in param_masks:
      new_mask = param_mask.copy()
      new_mask[index] = kv
      new_masks.append(new_mask)

  return gen_param_masks(remainder,new_masks)
  
def get_matching_data(results, pmask):
  
  keys = results.keys()
  matched_data = []
  for key in keys:
    if pmask[2] == "SP" and key[0] == "N":
      pmask[2] = "DP"
    elif pmask[2] == "DP" and key[0] == "K":
      pmask[2] = "SP"
      
    matches = [pmask[i] == key[i] or pmask[i]=="*" for i in range(len(pmask))]
    if False not in matches:
      matched_data.append(results[key])
  return matched_data
  
def add_matching_dict(original, pmask, trimmed_dict):
  
  keys = original.keys()
  for key in keys:
    if pmask[2] == "SP" and key[0] == "N":
      pmask[2] = "DP"
    elif pmask[2] == "DP" and key[0] == "K":
      pmask[2] = "SP"
      
    matches = [pmask[i] == key[i] or pmask[i]=="*" for i in range(len(pmask))]
    if False not in matches:
      trimmed_dict[key] = original[key]
  
def box_whisker(results, y_var, x_keys, base_mask_keys=None, func=None, y_axis="Y Default", title="Default"):

  labels = ["Rep:","Mut:","Cross:","Graph:","Process:","Deg Wtd:","Seed Size:"]

  base_masks = [["*","*","*","*","*","*","*",y_var]]
  pmasks = gen_param_masks(x_keys,param_masks=base_masks)
  
  if base_mask_keys != None:
    trimmed_dict = {}
    base_masks = gen_param_masks(base_mask_keys,base_masks)
    
    for bmask in base_masks:
      add_matching_dict(results,bmask,trimmed_dict)
  else:
    trimmed_dict = results.copy()

  data_sets = []
  for pmask in pmasks:
    data_set = get_matching_data(trimmed_dict,pmask)
    if func != None:
      data_set = [func(datum) for datum in data_set]
    data_sets.append(data_set)
    
  labels = []
  for i in range(len(pmasks)):
    labels.append(pmask_to_label(pmasks[i]))
  
  fig1, ax1 = plt.subplots()
  ax1.set_title(title)
  ax1.boxplot(data_sets,labels=labels)
  plt.xticks(rotation=90)
  ax1.set_ylabel(y_axis)
  plt.tight_layout()
  plt.show()
  
  
def relative_box_whisker(results, y_var, x_keys, base_mask_keys=None, func=None, y_axis="Y Default", title="Default"):

  labels = ["Rep:","Mut:","Cross:","Graph:","Process:","Deg Wtd:","Seed Size:"]

  base_masks = [["*","*","*","*","*","*","*",y_var]]
  pmasks = gen_param_masks(x_keys,param_masks=base_masks)
  
  if base_mask_keys != None:
    trimmed_dict = {}
    base_masks = gen_param_masks(base_mask_keys,base_masks)
    
    for bmask in base_masks:
      add_matching_dict(results,bmask,trimmed_dict)
  else:
    trimmed_dict = results.copy()
    
  data_sets = [[] for i in range(len(pmasks))]
  
  pmask1 = pmasks[0]
  keys_ordered = []
  for key in trimmed_dict:
    if pmask1[2] == "SP" and key[0] == "N":
      pmask1[2] = "DP"
    elif pmask1[2] == "DP" and key[0] == "K":
      pmask1[2] = "SP"
      
    matches = [pmask1[i] == key[i] or pmask1[i]=="*" for i in range(len(pmask1))]
    if False not in matches:
      data_sets[0].append(trimmed_dict[key])
      keys_ordered.append(key)
  
  for i in range(len(pmasks)-1):
    pmask = pmasks[i+1]

    for key in keys_ordered:
      temp_key = list(key)        
      temp_key = [pmask[i] if pmask[i] != "*" else temp_key[i] for i in range(len(pmask))]
      if temp_key[2] == "SP" and temp_key[0] == "N":
        temp_key[2] = "DP"
      elif temp_key[2] == "DP" and temp_key[0] == "K":
        temp_key[2] = "SP"
      temp_key = tuple(temp_key)
      data_sets[i+1].append(trimmed_dict[temp_key])
      
  if func != None:
    for i in range(len(data_sets)):
      data_sets[i] = [func(datum) for datum in data_sets[i]]
  
  data_sets = np.asarray(data_sets)
  data_sets = data_sets.astype(float)
  averages = np.average(data_sets,axis=0)
  data_sets -= averages

  labels = []
  for i in range(len(pmasks)):
    labels.append(pmask_to_label(pmasks[i]))
  
  fig1, ax1 = plt.subplots()
  ax1.set_title(title)
  ax1.boxplot(data_sets.T,labels=labels)
  plt.xticks(rotation=90)
  ax1.set_ylabel(y_axis)
  plt.tight_layout()
  plt.show()
   
def pmask_to_label(pmask):
  
  labels = ["R:","M:","C:","G:","P:","DW:","K:"]
  label = ""
  for i in range(len(pmask)-1):
    if pmask[i] != "*":
      label += labels[i] + str(pmask[i]) + ", "
  return label
        
def time_to_find(fitness_over_time):
  
  best = max(fitness_over_time)
  return np.argwhere(np.array(fitness_over_time) >= best*.99)[0][0]

  

# GA variant component functions

# N = Size of graph in nodes
# K = num of communities
# a = intra community link probability OR average intra community degree
# b = inter community link probability OR average inter community degree
def gen_sbm(N,K,a,b,probabilities=False):

  am = np.random.uniform(size=(N,N))
  C = int(N/K)
  
  if not probabilities:
    a = a/C
    b = b/(N-C)
 
  for r in range(K):
    for s in range(r+1):
      slice = am[r*C:(r+1)*C,s*C:(s+1)*C]
      if r == s:
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(slice < a, 1.0, 0.0)
      else:
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(slice < b, 1.0, 0.0)
  am = np.tril(am,-1) + np.tril(am,-1).T
  return eg.Experiment_Graph("sbm",am=am)
  
# N = Size of graph in nodes
# K = num of communities
# a = intra community link probability OR average intra community degree
# b = inter community link probability OR average inter community degree
def gen_dc_sbm(N,K,a,b,gamma,kmin,kmax,probabilities=False):

  am = np.random.uniform(size=(N,N))
  C = int(N/K)
  
  if not probabilities:
    a = a/C
    b = b/(N-C)
  
  #print(np.around(am,1))
  
  node_popularities = []
  for r in range(K):
    comm_degs = powerlaw_degrees(gamma,kmin,kmax,C)
    sum_deg = sum(comm_degs)
    node_popularities += [cd/sum_deg for cd in comm_degs]
    #alpha = (a*C)/sum(node_popularities)
  node_popularities = np.array(node_popularities)
  #node_popularities = node_popularities.reshape(1,N)
  #print(node_popularities)
  
  targets = np.outer(node_popularities,node_popularities)
  
  #print(np.around(am,1)) 
  C2 = C**2
 
  for r in range(K):
    for s in range(r+1):
      rand_slice = am[r*C:(r+1)*C,s*C:(s+1)*C]
      target_slice = targets[r*C:(r+1)*C,s*C:(s+1)*C]
      target_sum = np.sum(target_slice)
      if r == s:
        wrs_u = a*C2/target_sum
        target_slice *= wrs_u
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(rand_slice < target_slice, 1.0, 0.0)
      else:
        wrs_u = b*C2/target_sum
        target_slice *= wrs_u
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(rand_slice < target_slice, 1.0, 0.0)
  am = np.tril(am,-1) + np.tril(am,-1).T
  #print(np.around(am,1))
  return eg.Experiment_Graph("sbm",am=am)

def sbm_gen_params(N,groups,avg_deg_intra,avg_deg_inter):

  sbm_membership = [int(i/(N/groups)) for i in range(N)]
  inter_edges = avg_deg_inter * (N / groups)
  intra_edges = 2 * avg_deg_intra * (N / groups)
  inter_comm_edges = np.full((groups,groups),inter_edges)
  np.fill_diagonal(inter_comm_edges,intra_edges)
  return [sbm_membership, inter_comm_edges]
  
def powerlaw_degrees(gamma,kmin,kmax,N):
  pdf = np.array([x**-gamma for x in range(kmin,kmax+1)])
  pdf = pdf / np.sum(pdf)
  return np.random.choice(range(kmin,kmax+1),size=N,p=pdf)

## FIT PROPORTIONATE SELECTION ##

def fit_prop_select(pool,tournament_size=None):
  fitnesses = np.array([e[1] for e in pool])
  selection_chance = fitnesses / np.sum(fitnesses)
  selections = np.random.choice(np.arange(len(pool)),size=2,p=fitnesses)
  
  return [pool[i] for i in selections]
  

## FITNESS ##

def klist_fit_wrapper(graph,trials,process,process_params,k):

  # two fitnesses returned to match signature / handling in simple_ga
  # facilitates scaling over time (not necessary here)
  def klist_fitness(individual,scaling_factor,fit_dict):
    
    if tuple(individual) in fit_dict:
      return fit_dict[tuple(individual)], fit_dict[tuple(individual)]

    sum_infected = 0
    seed_set = np.zeros(graph.N)
    seed_set[individual] = 1
    process_params["seed_set"] = seed_set
    
    if trials == 1:
      fitness = process(**process_params)[0]
    else:
      for x in range(trials):
        sum_infected += process(**process_params)[0]
      
      fitness = sum_infected / trials
    
    return fitness, fitness
 
  return klist_fitness
      
  
def nlist_fit_wrapper(graph,trials,process,process_params,k):

  # two fitnesses returned, one scaled, one pure
  # facilitates quick updating 
  def nlist_fitness(individual,scaling_factor,fit_dict):
    if len(individual) == 0:
      return 0,0
  
    scaling_factor_2 = 1-scaling_factor # 0 -> end generation
    
    if tuple(individual) in fit_dict:
      excess = max(0,len(individual)-k)
      if scaling_factor_2 == 0:
        if excess == 0:
          return fit_dict[tuple(individual)], fit_dict[tuple(individual)]
        return 0,0

      
      scaled_excess = excess/(scaling_factor_2**(excess)*k)
      penalty = 1/(1+scaled_excess) #2/(1+np.exp(2*scaled_excess))
      fitness = fit_dict[tuple(individual)]
      #fitness /= (1+excess)
      
      return fitness*penalty, fitness #(scaling_factor)*penalty+fitness*(1-scaling_factor), fitness
    
    sum_infected = 0
    seed_set = np.zeros(graph.N)
    seed_set[individual] = 1
    process_params["seed_set"] = seed_set

    for x in range(trials):
      sum_infected += process(**process_params)[0]
    
    fitness = sum_infected / trials
    
    excess = max(0,len(individual)-k)
    if scaling_factor_2 == 0:
      if excess == 0:
        return fitness, fitness
      return 0,0
    
    excess = max(0,len(individual)-k)
    #fitness /= (1+excess)
    scaled_excess = excess/(scaling_factor_2**(excess)*k)
    penalty = 1/(1+scaled_excess) #2/(1+np.exp(2*scaled_excess)) 
    
    return fitness*penalty, fitness #(scaling_factor)*penalty+fitness*(1-scaling_factor), fitness
 
  return nlist_fitness
  
  
## MUTATION ##
  
def nlist_mutate(graph,k,mutate_type="random",node_selection_probs=np.array([]),degree_wtd=False):
  
  def aggressive_mutate(ind_x):
    
    num_pop = r.randint(0,max(1,len(ind_x)-k))
    index = r.randint(0,len(ind_x)-1)
    if index + num_pop > len(ind_x):
      leftover = len(ind_x) - (index+num_pop)
      return ind_x[leftover:index]
    return ind_x[:index] + ind_x[index+num_pop:]
  
  def random_mutate(ind,pr_mutation):
    individual = ind.copy()
    if len(individual) == 0 or len(individual) == graph.N:
      return individual
    if r.random() < pr_mutation:
      if len(individual) < k:
        dec_prob,inc_prob = [.4,.8]
      else:
        dec_prob,inc_prob = [.8,.4]      
      if r.random() < dec_prob:
        individual = aggressive_mutate(individual)
      if r.random() < inc_prob:
        node_probs = np.copy(node_selection_probs)

        node_probs[individual] = 0.0 # take our individual's current member nodes out of the hat
          
        node_probs /= np.sum(node_probs) # renormalize probabilities
        #print("Random\n",node_probs,"\n")
        new_member = np.random.choice(graph.N,p=node_probs)
 
        bisect.insort(individual,new_member)
    
    return individual
    
  def neighbor_mutate(ind,pr_mutation):
    individual = ind.copy()
    if len(individual) == 0 or len(individual) == graph.N:
      return individual
    if r.random() < pr_mutation:
      if len(individual) < k:
        dec_prob,inc_prob = [.4,.8]
      else:
        dec_prob,inc_prob = [.8,.4]      
      if r.random() < dec_prob:
        individual = aggressive_mutate(individual)
      if r.random() < inc_prob:
        node_probs = np.copy(node_selection_probs)
  
        np_individual = np.zeros(graph.N)
        np_individual[individual] = 1.0
        node_probs = np.where(graph.adj_mat * np_individual != 0, node_probs, 0)
        node_probs[individual] = 0.0
          
        if np.sum(node_probs) > 0:
          node_probs /= np.sum(node_probs)
          #print("Neighbor\n",individual,node_probs,"\n")
          new_member = np.random.choice(graph.N,p=node_probs)
          bisect.insort(individual,new_member)
    
    return individual
  
  def distance_mutate(ind,pr_mutation):
    individual = ind.copy()
    if len(individual) == 0 or len(individual) == graph.N:
      return individual
    if r.random() < pr_mutation:
      if len(individual) < k:
        dec_prob,inc_prob = [.4,.8]
      else:
        dec_prob,inc_prob = [.8,.4]      
      if r.random() < dec_prob:
        individual = aggressive_mutate(individual)
      if r.random() < inc_prob and len(individual) < graph.N and len(individual) > 0:
        origin = individual[r.randint(0,len(individual)-1)]
        distances = graph.get_distances()[origin]
        median = np.median(distances)
        distant_nodes = np.argwhere(distances >= median).T[0]
        
        node_probs = np.copy(node_selection_probs)
        node_probs[individual] = 0
        node_probs = node_probs[distant_nodes]
        
        if np.sum(node_probs) > 0:
          node_probs /= np.sum(node_probs)
          #print("Distance\n",individual, origin, half, distances,node_probs,"\n")
          new_node = np.random.choice(distant_nodes,p=node_probs)
          bisect.insort(individual,new_node)
        
    return individual 
    
  def null_mutate(ind,pr_mutation):
    individual = ind.copy()
    return individual
    
  if not np.any(node_selection_probs):
    node_selection_probs = np.ones(graph.N)
    
  if degree_wtd:
    node_selection_probs = graph.get_deg_seq(relative=True)
  
  if mutate_type == "random":
    return random_mutate
  elif mutate_type == "neighbor":
    return neighbor_mutate
  elif mutate_type == "distance":
    return distance_mutate
  else:
    print("Warning: type of mutation not recognized, no mutation will occur.")
    return null_mutate
    
  
def klist_mutate(graph,k,mutate_type="random",node_selection_probs=np.array([]),degree_wtd=False):
    
  def random_mutate(ind,pr_mutation):
    individual = ind.copy()
    
    if r.random() < pr_mutation:
      x = individual.pop(r.randint(0,len(individual)-1))
      new_node = ind[0]
      while new_node in ind:
        new_node = r.randint(0,graph.N-1)
      bisect.insort(individual,new_node)

      return individual

      if degree_wtd:
        node_probs = np.copy(node_selection_probs)
        node_probs[individual] = 0
        node_probs /= np.sum(node_probs)
      
        new_node = np.random.choice(graph.N,p=node_probs)
        print("?")
      else:
        new_node = ind[0]
        while new_node in ind:
          new_node = r.randint(0,graph.N-1)
      individual.append(new_node)
      
      #bisect.insort(individual,new_node)
  
      #individual.sort()
    return individual
    
  def neighbor_mutate(ind,pr_mutation):
    individual = ind.copy()
    
    if r.random() < pr_mutation:
      individual.pop(r.randint(0,len(individual)-1))
     
      np_individual = np.zeros(graph.N)
      np_individual[individual] = 1.0
      node_probs = np.where(graph.adj_mat * np_individual != 0, node_selection_probs, 0)
      node_probs[individual] = 0.0
        
      node_probs /= np.sum(node_probs)
      
      new_node = np.random.choice(graph.N,p=node_probs)
      bisect.insort(individual,new_node)

    return individual
    
  def distance_mutate(ind,pr_mutation):
    individual = ind.copy()
    
    if r.random() < pr_mutation:
      origin = individual.pop(r.randint(0,len(individual)-1))
      distances = graph.get_distances()[origin]
      median = np.median(distances)
      distant_nodes = np.argwhere(distances >= median).T[0]
     
      node_probs = np.copy(node_selection_probs)
      node_probs[individual] = 0
      node_probs = node_probs[distant_nodes]
      
      node_probs /= np.sum(node_probs)
      
      new_node = np.random.choice(distant_nodes,p=node_probs)
      bisect.insort(individual,new_node)

    return individual
      
  def null_mutate(ind,pr_mutation):
    individual = ind.copy()
    return individual
    
  if not np.any(node_selection_probs):
    node_selection_probs = np.ones(graph.N)
    
  if degree_wtd:
    node_selection_probs = graph.get_deg_seq(relative=True)
  
  if mutate_type == "random":
    return random_mutate
  elif mutate_type == "neighbor":
    return neighbor_mutate
  elif mutate_type == "distance":
    return distance_mutate
  else:
    print("Warning: type of mutation not recognized, no mutation will occur.")
    return null_mutate
    

## CROSSOVER ##
      
def k_list_crossover(graph, k, pr_crossover, crossover_type="single_point",node_selection_probs=np.array([]), degree_wtd=False):
  
  def single_point(individual_a, individual_b):
    ind_a = individual_a.copy()
    ind_b = individual_b.copy()
    
    if ind_a == ind_b:
      return ind_a, ind_b
    
    if r.random() < pr_crossover and ind_a != ind_b:
      
      unique_a = [a for a in ind_a if a not in ind_b]
      unique_b = [b for b in ind_b if b not in ind_a]
      if len(unique_a) != len(unique_b):
        print("Unexpected Input: Individuals of unequal size or with duplicate members.")
      crossover_point = r.randint(0,len(unique_a))
      
      each = [a for a in ind_a if a in ind_b]
        
      temp_a = unique_a.copy()
      add_a = unique_a[0:crossover_point] + unique_b[crossover_point:]
      add_b = unique_b[0:crossover_point] + unique_a[crossover_point:]
      
      ind_a = each + add_a
      ind_b = each + add_b
      
      if len(ind_a) != k or len(ind_b) != k:
        print("Unexpected Size: Input or result was not length",k,":\n",ind_a,"\n",ind_b)
        ind_a = ind_a[0:k]
        ind_b = ind_b[0:k]
 
      ind_a.sort()
      ind_b.sort()
      
    return ind_a, ind_b
    
  def network_mask(individual_a, individual_b):
    ind_a = individual_a.copy()
    ind_b = individual_b.copy()
    
    if ind_a == ind_b:
      return ind_a, ind_b
    
    if r.random() < pr_crossover and ind_a != ind_b:
    
      unique_a = [a for a in ind_a if a not in ind_b]
      unique_b = [b for b in ind_b if b not in ind_a]
      if len(unique_a) != len(unique_b):
        print("Unexpected Input: Individuals of unequal size or with duplicate members.")
        print(ind_a,"\n",ind_b)
      crossover_point = r.randint(0,len(unique_a))
      
      each = [a for a in ind_a if a in ind_b]
      
      uniques = unique_a + unique_b
      #print(uniques)
     
      # Get a list of size |crossover_point| by starting from an element in unique_b
      # and retrieving |crossover_point| nodes that are closest to that origin in uniques
      # we will add these to individual A
      origin_a = r.sample(unique_b,1)[0] 
      distance_og_a = graph.get_distances()[origin_a]
      distance_pairs = [(u,distance_og_a[u]) for u in uniques]
      distance_pairs.sort(key = operator.itemgetter(1))
      
      add_a = [e[0] for e in distance_pairs[0:crossover_point]]
      
      uniques = [u for u in uniques if u not in add_a]
      
      # Vice versa for elements to add to individual B
      origin_b = r.sample(uniques,1)[0]
      distance_og_b = graph.get_distances()[origin_b]
      distance_pairs = [(u,distance_og_b[u]) for u in uniques]
      distance_pairs.sort(key = operator.itemgetter(1))
      
      add_b = [e[0] for e in distance_pairs[0:crossover_point]]
      
      uniques = [u for u in uniques if u not in add_b]
      
      # Remaining elements are agnostically divided back to A and B
      # if the crossover was evenly distributed, A and B will receive back
      # their original unswapped nodes 
      if len(uniques) > 0:
        #print(add_a,add_b,uniques)
        cross_2 = int(len(uniques)/2)
        add_a += uniques[0:cross_2]
        add_b += uniques[cross_2:]
      
      ind_a = each + add_a
      ind_b = each + add_b
      
      if len(ind_a) != k or len(ind_b) != k:
        print("Unexpected Size: Input or result was not length",k,":\n",ind_a,"\n",ind_b)
        ind_a = ind_a[0:k]
        ind_b = ind_b[0:k]
 
      ind_a.sort()
      ind_b.sort()
      
    return ind_a, ind_b
    
  def degree_cooperation(individual_a, individual_b):
    ind_a = individual_a.copy()
    ind_b = individual_b.copy()
    
    if ind_a == ind_b:
      return ind_a, ind_b
    
    if r.random() < pr_crossover and ind_a != ind_b:
      
      unique_a = [a for a in ind_a if a not in ind_b]
      unique_b = [b for b in ind_b if b not in ind_a]
      if len(unique_a) != len(unique_b):
        print("Unexpected Input: Individuals of unequal size or with duplicate members.")
      crossover_point = r.randint(0,len(unique_a))
      
      each = [a for a in ind_a if a in ind_b]
      
      node_wts = np.copy(node_selection_probs)
      if np.all(node_wts == np.ones(graph.N)):
        node_wts = graph.get_deg_seq()
        
      a_by_wts = [(a,node_wts[a]) for a in unique_a]
      a_by_wts.sort(key = operator.itemgetter(1))
      
      b_by_wts = [(b,node_wts[b]) for b in unique_b]
      b_by_wts.sort(key = operator.itemgetter(1))
      
      add_a = a_by_wts[0:crossover_point] + b_by_wts[crossover_point:]
      add_b = b_by_wts[0:crossover_point] + a_by_wts[crossover_point:]
      
      add_a = [a[0] for a in add_a]
      add_b = [b[0] for b in add_b]
      
      ind_a = each + add_a
      ind_b = each + add_b
      
      if len(ind_a) != k or len(ind_b) != k:
        print("Unexpected Size: Input or result was not length",k,":\n",ind_a,"\n",ind_b)
        ind_a = ind_a[0:k]
        ind_b = ind_b[0:k]
 
      ind_a.sort()
      ind_b.sort()
      
    return ind_a, ind_b
    
  def null_crossover(individual_a, individual_b):
    ind_a = individual_a.copy()
    ind_b = individual_b.copy()
    return ind_a, ind_b
    
  if not np.any(node_selection_probs):
    node_selection_probs = np.ones(graph.N)
    
  if degree_wtd:
    node_selection_probs = graph.get_deg_seq(relative=True)
  
  if crossover_type == "single_point":
    return single_point
  elif crossover_type == "degree_cooperation":
    return degree_cooperation
  elif crossover_type == "network_mask":
    return network_mask
  else:
    print("Warning: type of crossover not recognized, no crossover will occur.")
    return null_crossover
    
    
def n_list_crossover(graph, k, pr_crossover, crossover_type="single_point",node_selection_probs=np.array([]), degree_wtd=False):
  
  def double_point(individual_a, individual_b):
    ind_a = individual_a.copy()
    ind_b = individual_b.copy()
    
    if ind_a == ind_b:
      return ind_a, ind_b
    
    if r.random() < pr_crossover and ind_a != ind_b:
      
      unique_a = [a for a in ind_a if a not in ind_b]
      unique_b = [b for b in ind_b if b not in ind_a]

      crossover_a = r.randint(0,len(unique_a))
      crossover_b = r.randint(0,len(unique_b))
      
      each = [a for a in ind_a if a in ind_b]
        
      add_a = unique_a[crossover_a:] + unique_b[:crossover_b]
      add_b = unique_a[:crossover_a] + unique_b[crossover_b:]
      
      ind_a = each + add_a
      ind_b = each + add_b
      
      ind_a.sort()
      ind_b.sort()
      
    return ind_a, ind_b
    
  def network_mask(individual_a, individual_b):
    ind_a = individual_a.copy()
    ind_b = individual_b.copy()
    
    if ind_a == ind_b:
      return ind_a, ind_b    
    
    if r.random() < pr_crossover and ind_a != ind_b:
    
      unique_a = [a for a in ind_a if a not in ind_b]
      unique_b = [b for b in ind_b if b not in ind_a]

      each = [a for a in ind_a if a in ind_b]
      
      uniques = unique_a + unique_b
      if len(uniques) == 0:
        print(ind_a, ind_b)
      crossover_point = r.randint(0,len(uniques))
     
      # Get a list of size |crossover_point| by starting from an element in unique_b
      # and retrieving |crossover_point| nodes that are closest to that origin in uniques
      # we will add these to individual A
      if len(unique_b) > 0:
        origin_a = r.sample(unique_b,1)[0] 
      else:
        origin_a = r.sample(uniques,1)[0] 
        
      distance_og_a = graph.get_distances()[origin_a]
      distance_pairs = [(u,distance_og_a[u]) for u in uniques]
      distance_pairs.sort(key = operator.itemgetter(1))
      
      add_a = [e[0] for e in distance_pairs[0:crossover_point]]
      
      add_b = [u for u in uniques if u not in add_a]
      
      ind_a = each + add_a
      ind_b = each + add_b
 
      ind_a.sort()
      ind_b.sort()
      
    return ind_a, ind_b
    
  def degree_cooperation(individual_a, individual_b):
    ind_a = individual_a.copy()
    ind_b = individual_b.copy()
    
    if ind_a == ind_b:
      return ind_a, ind_b
    
    if r.random() < pr_crossover and ind_a != ind_b:
      
      unique_a = [a for a in ind_a if a not in ind_b]
      unique_b = [b for b in ind_b if b not in ind_a]

      crossover_a = r.randint(0,len(unique_a))
      crossover_b = r.randint(0,len(unique_b))
      
      each = [a for a in ind_a if a in ind_b]
      
      node_wts = np.copy(node_selection_probs)
      if np.all(node_wts == np.ones(graph.N)):
        node_wts = graph.get_deg_seq()
        
      a_by_wts = [(a,node_wts[a]) for a in unique_a]
      a_by_wts.sort(key = operator.itemgetter(1))
      
      b_by_wts = [(b,node_wts[b]) for b in unique_b]
      b_by_wts.sort(key = operator.itemgetter(1))
      
      add_a = a_by_wts[0:crossover_a] + b_by_wts[crossover_b:]
      add_b = b_by_wts[0:crossover_b] + a_by_wts[crossover_a:]
      
      add_a = [a[0] for a in add_a]
      add_b = [b[0] for b in add_b]
      
      ind_a = each + add_a
      ind_b = each + add_b
 
      ind_a.sort()
      ind_b.sort()
      
    return ind_a, ind_b
    
  def null_crossover(individual_a, individual_b):
    ind_a = individual_a.copy()
    ind_b = individual_b.copy()
    return ind_a, ind_b
    
  if not np.any(node_selection_probs):
    node_selection_probs = np.ones(graph.N)
    
  if degree_wtd:
    node_selection_probs = graph.get_deg_seq(relative=True)
  
  if crossover_type == "double_point":
    return double_point
  elif crossover_type == "degree_cooperation":
    return degree_cooperation
  elif crossover_type == "network_mask":
    return network_mask
  else:
    print("Warning: type of crossover not recognized, no crossover will occur.")
    return null_crossover
    
def klist_gen(graph, k):
  
  def k_ind():
    baby = r.sample(range(graph.N-1),k)
    baby.sort()
    return baby
   
  return k_ind
  
def nlist_gen(graph, k):
  
  def n_ind():
    baby = r.sample(range(graph.N-1),r.randint(1,graph.N-1))
    baby.sort()
    return baby
  
  return n_ind
  
def check_k(k):
  
  def k_check(ind):
    return len(ind) == k
    
  return k_check
  
def read_input(filename):

  filename = "graphs/" + filename
  with open(filename,'r') as tsvin:
    row_iter = csv.reader(tsvin, delimiter='\n')
    graph = nx.Graph()

    for element in row_iter:
      row = element[0].split()
      u = int(row[0])
      v = int(row[1])
      graph.add_edge(u,v)
      
  return graph  
  
def get_lcc(graph):
  
  large_comp = max(nx.connected_components(graph), key=len)
  return graph.subgraph(list(large_comp))
    
def get_fb_2():

  g = get_lcc(read_input('fb_2.txt'))
  read_graph = eg.Experiment_Graph("fb_2_LCC",nxgraph = g)
  return read_graph
  
def ba_test_graph(N,m):
  g = nx.barabasi_albert_graph(N,m)
  return eg.Experiment_Graph("BA_test",nxgraph = g)
  
def run_aggregate_tests():

  g = nx.Graph()
  g.add_edges_from([(0,1),(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(6,8),(6,9)])
  test_graph = eg.Experiment_Graph("test",nxgraph=g)
 
  LT_params = {"seed_set":None, "a_threshold":2, "type":"absolute"}
  
  IC_params = {"seed_set":None, "c":.5}
  
  GA_params = {"pr_mutate":.5,"iterations":10,"pool_size":8,"tournament_size":2}

  k = 2
  klist_fit_func = klist_fit_wrapper(test_graph,10,test_graph.LT,LT_params,k)
  distant_mutate = klist_mutate(test_graph,k,mutate_type="distance",degree_wtd=True)
  kdegree = k_list_crossover(test_graph, k, 1.0, crossover_type="degree_cooperation", degree_wtd=True)
  kgen = klist_gen(test_graph,k)
  kcheck = check_k(k)
  
  klist_ga = sga.GA_generator(klist_fit_func, kgen, GA_params, mutator = distant_mutate, reproducer = kdegree,
    constraint_checker = kcheck,fitness_processes_per_eval=5,num_elites=2,debug=True)
  print(klist_ga())
  
  GA_params = {"pr_mutate":1.0,"iterations":50,"pool_size":50,"tournament_size":2}
  
  k = 2
  nlist_fit_func = nlist_fit_wrapper(test_graph,1,test_graph.LT,LT_params,k)
  distant_mutate = nlist_mutate(test_graph,k,mutate_type="distance",degree_wtd=True)
  nmask = n_list_crossover(test_graph,k, 1.0, crossover_type="network_mask", degree_wtd=True)  
  ngen = nlist_gen(test_graph,k)
  
  nlist_ga = sga.GA_generator(nlist_fit_func, ngen, GA_params, mutator = distant_mutate, reproducer = nmask,
    fitness_processes_per_eval=1,num_elites=1,debug=True)
  print(nlist_ga())
  
def run_component_tests():

  g = nx.Graph()
  g.add_edges_from([(0,1),(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(6,8),(6,9)])
  test_graph = eg.Experiment_Graph("test",nxgraph=g)
  print(test_graph.adj_mat)
  
  seed_set = np.zeros(10)
  seed_set[0] = 1
  
  LT_params = {"seed_set":seed_set, "a_threshold":2, "type":"absolute"}
  
  IC_params = {"seed_set":None, "c":.8}
  
  print("KList fitness on IC\n")
  klist_fit_func = klist_fit_wrapper(test_graph,10,test_graph.IC,IC_params,1)
  print(klist_fit_func([0],0,{}))
  klist_fit_func = klist_fit_wrapper(test_graph,10,test_graph.IC,IC_params,2)
  print(klist_fit_func([0,8],0,{}))
  print(klist_fit_func([0,8],0,{(0,8):-100}))
  
  print("\nNlist Fitness Tests on LT\n")
  nlist_fit_func = nlist_fit_wrapper(test_graph,10,test_graph.LT,LT_params,2)
  print(nlist_fit_func([0],0,{}))
  print(nlist_fit_func([0,2,4,8],0,{}))
  print(nlist_fit_func([0,2,4,8],.5,{}))
  print(nlist_fit_func([0,2,4,8],1,{}))
  print(nlist_fit_func([0,8],0,{(0,8):-100}))
 
  rand_mutate = nlist_mutate(test_graph,2,mutate_type="random",degree_wtd=False)
  neighbor_mutate = nlist_mutate(test_graph,2,mutate_type="neighbor",degree_wtd=False)
  distant_mutate = nlist_mutate(test_graph,2,mutate_type="distance",degree_wtd=False)
  
  ind = [1,5]
  print("\nNlist Mutate Tests Unweighted:",ind,"\n")
  for x in range(10):
    mutate_tests = [rand_mutate(ind,1.0),neighbor_mutate(ind,1.0),distant_mutate(ind,1.0)]
    line_length = 10
    pad1 = "   "*(line_length - len(mutate_tests[0]))
    pad2 = "   "*(line_length - len(mutate_tests[1]))
    mutate_tests.insert(1,pad1)
    mutate_tests.insert(3,pad2)
    print("{} {} {} {} {}".format(*mutate_tests))
    

  ind = [1,5]
  k = len(ind)
  rand_mutate = nlist_mutate(test_graph,k,mutate_type="random",degree_wtd=True)
  neighbor_mutate = nlist_mutate(test_graph,k,mutate_type="neighbor",degree_wtd=True)
  distant_mutate = nlist_mutate(test_graph,k,mutate_type="distance",degree_wtd=True)
  
  print("\nNlist Mutate Tests Weighted:",ind,"\n")
  print(test_graph.get_deg_seq(relative=True))
  for x in range(10):
    mutate_tests = [rand_mutate(ind,1.0),neighbor_mutate(ind,1.0),distant_mutate(ind,1.0)]
    line_length = 10
    pad1 = "   "*(line_length - len(mutate_tests[0]))
    pad2 = "   "*(line_length - len(mutate_tests[1]))
    mutate_tests.insert(1,pad1)
    mutate_tests.insert(3,pad2)
    print("{} {} {} {} {}".format(*mutate_tests))
    
    
  rand_mutate = klist_mutate(test_graph,k,mutate_type="random",degree_wtd=False)
  neighbor_mutate = klist_mutate(test_graph,k,mutate_type="neighbor",degree_wtd=False)
  distant_mutate = klist_mutate(test_graph,k,mutate_type="distance",degree_wtd=False)
  
  ind = [1,5]
  print("\nKlist Mutate Tests Unweighted:",ind,"\n")
  for x in range(10):
    mutate_tests = [rand_mutate(ind,1.0),neighbor_mutate(ind,1.0),distant_mutate(ind,1.0)]
    line_length = 10
    pad1 = "   "*(line_length - len(mutate_tests[0]))
    pad2 = "   "*(line_length - len(mutate_tests[1]))
    mutate_tests.insert(1,pad1)
    mutate_tests.insert(3,pad2)
    print("{} {} {} {} {}".format(*mutate_tests))    
    
  rand_mutate = klist_mutate(test_graph,k,mutate_type="random",degree_wtd=True)
  neighbor_mutate = klist_mutate(test_graph,k,mutate_type="neighbor",degree_wtd=True)
  distant_mutate = klist_mutate(test_graph,k,mutate_type="distance",degree_wtd=True)
  
  ind = [1,5]
  print("\nKlist Mutate Tests Weighted:",ind,"\n")
  print(test_graph.get_deg_seq(relative=True))
  for x in range(10):
    mutate_tests = [rand_mutate(ind,1.0),neighbor_mutate(ind,1.0),distant_mutate(ind,1.0)]
    line_length = 10
    pad1 = "   "*(line_length - len(mutate_tests[0]))
    pad2 = "   "*(line_length - len(mutate_tests[1]))
    mutate_tests.insert(1,pad1)
    mutate_tests.insert(3,pad2)
    print("{} {} {} {} {}".format(*mutate_tests))
    

  ksingle = k_list_crossover(test_graph, 3, 1.0, crossover_type="single_point", degree_wtd=True)
  kdegree = k_list_crossover(test_graph, 3, 1.0, crossover_type="degree_cooperation", degree_wtd=True)
  kmask = k_list_crossover(test_graph, 3, 1.0, crossover_type="network_mask", degree_wtd=True)    
  inda = [1,3,5]
  indb = [5,6,9]
  k = len(inda)
  print("\nKlist Crossover Tests Weighted:",inda,indb,"\n")
  for x in range(10):
    tests = [ksingle(inda,indb),kdegree(inda,indb),kmask(inda,indb)]
    pad1 = "\t"
    pad2 = "\t"
    tests.insert(1,pad1)
    tests.insert(3,pad2)
    print("{} {} {} {} {}".format(*tests))
    
  nsingle = n_list_crossover(test_graph,k, 1.0, crossover_type="double_point", degree_wtd=True)
  ndegree = n_list_crossover(test_graph,k, 1.0, crossover_type="degree_cooperation", degree_wtd=True)
  nmask = n_list_crossover(test_graph,k, 1.0, crossover_type="network_mask", degree_wtd=True)    
  inda = [1,3,5]
  indb = [5,6,9]
  print("\nNlist Crossover Tests Weighted:",inda,indb,"\n")
  for x in range(10):
    tests = [nsingle(inda,indb),ndegree(inda,indb),nmask(inda,indb)]
    pad1 = "\t"
    pad2 = "\t"
    tests.insert(1,pad1)
    tests.insert(3,pad2)
    print("{} {} {} {} {}".format(*tests))
  
if __name__ == "__main__":
  # run_component_tests()
  # run_aggregate_tests()
  main()