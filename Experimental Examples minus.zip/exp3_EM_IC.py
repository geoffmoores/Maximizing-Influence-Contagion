import sys
import time
import numpy as np
import random as r
import networkx as nx
import scipy as sci
import matplotlib as mpl
import matplotlib.pyplot as plt
import csv
import copy
import igraph as ig
import graph_tool.all as gt
import re
from os import path as ospath
from scipy.sparse import csr_matrix
from scipy.sparse import lil_matrix
from scipy.special import zeta
import pickle
from sklearn.metrics import mutual_info_score
import scipy.stats
import operator
import collections
import traceback
import bisect

import simple_GA as sga
import experiment_graph as eg
import graph_greedy as gg

def main():
  
  ## GRAPH GENERATION ##
  
  graphs_per_type = 1
  graph_sizes = [500,1000,2000]
  graph_types = ["BA","SBM","DCSBM","RW"]
  ba_degs = [1.0, 2.0, 3.0, 4.0, 5.0]
  rw_keys = [0,1,2,3,4]
  
  rwn_2000 = [('bio-yeast-protein-inter','biological',0),('power-bcspwr09','power',1),
    ('soc-hamsterster','social',2),('ca-CSphd','collaboration',3),('socfb-Simmons81','facebook',4)]
  rwn_1000 = [('inf-euroroad','infrastructure',0),('power-eris1176','power',1),
    ('email-univ','email',2),('rt-twitter-copen','retweet',3),('soc-wiki-Vote','social',4)]
  rwn_500 = [('bio-diseasome','biological',0),('bio-celegans','biological',1),
    ('fb-pages-food','social',2),('ia-infect-dublin','interaction',3),('aves-weaver-social','animal_social',4)]
  
  rwn_keys = {500:rwn_500, 1000:rwn_1000, 2000:rwn_2000}
  
  sbm_keys = [] 
  for avg_intra in [1.0,3.0,5.0]:
    for avg_inter in [1.0,3.0,5.0]:
      if avg_intra == avg_inter:
        continue
      sbm_keys.append((avg_intra,avg_inter))
      
  param_by_type = {"BA":ba_degs,"SBM":sbm_keys,"DCSBM":sbm_keys,"RW":rw_keys}
  
  if ospath.exists("all_graphs_P2.p"):
    with open("all_graphs_P2.p","rb") as f:
      all_graphs = pickle.load(f)
  else:
    print("error, no graphs found")

    # all_graphs = {}
  
    # ba_graphs = {}
    # for avg_deg in ba_degs:
      # for size in graph_sizes:
        # ba_graphs[avg_deg,size] = ba_graph(size,avg_deg)
    # all_graphs["BA"] = ba_graphs
    
    # sbms = {}
    # for sbm_key in sbm_keys:
      # for size in graph_sizes:
        # sbms[sbm_key,size] = gen_sbm(size,10,sbm_key[0],sbm_key[1])
    # all_graphs["SBM"] = sbms
    
    # dc_sbms = {}
    # for sbm_key in sbm_keys:
      # for size in graph_sizes:
        # dc_sbms[sbm_key,size] = gen_dc_sbm(size,10,sbm_key[0],sbm_key[1],2,2,int(size/2))
    # all_graphs["DCSBM"] = dc_sbms
    
    # rwns = {}
    # for size in graph_sizes:
      # for rwn in rwn_keys[size]:
        # gname,gtype,ind = rwn
        # rwn_eg = eg.load_graph(gname,gtype,reload=False)
        # rwns[ind,size] = rwn_eg
        # print(gname,gtype,ind)
    # all_graphs["RW"] = rwns
  
    # with open("all_graphs_P2.p","wb") as f:
      # pickle.dump(all_graphs, f)
      
  ## ESTABLISH TEMP SETTINGS FOR ADV / EM EXPS ##
  # for key in all_graphs:  
    # for key2 in all_graphs[key]:
      # test_graph = all_graphs[key][key2]
      
      # patient_zero = r.randint(0,test_graph.N)
      # em_seed = list(test_graph.nxgraph.neighbors(patient_zero))[0:9]
      # em_seed.append(patient_zero)
      # seed_set = np.zeros(test_graph.N)
      # seed_set[em_seed] = 1
      # test_graph.temp["EM_seed"] = seed_set
      # print("**",test_graph.gname,"**")
      # print(test_graph.temp["adv_set","ADV_LT"])
      # test_graph.temp["adv_set","ADV_UC"] = temp_grab(test_graph,("adv_set","ADV_UC"),top_K,[test_graph,deg,10],overwrite=True)
      # test_graph.temp["adv_set","ADV_LT"] = temp_grab(test_graph,("adv_set","ADV_LT"),top_K,[test_graph,deg,10],overwrite=True)
      # print(test_graph.temp["adv_set","ADV_LT"])

    # with open("all_graphs_P2.p","wb") as f:
      # pickle.dump(all_graphs, f)
   
  # CC = exp_inf_wrapper("CC",{"seed_set":None, "threshold":.10,"mode":2,"c":1.0},trials=5)
  # UC = exp_inf_wrapper("UC",{"seed_set":None, "c":.8},trials=5)
  # IC = exp_inf_wrapper("IC",{"seed_set":None, "c":.2},trials=5)
  # IC_res = exp_inf_wrapper("IC",{"seed_set":None, "c":.2},trials=50)
  # LT = exp_inf_wrapper("LT",{"seed_set":None, "r_threshold":.3, "type":"relative"},trials=1)
  # EM_IC = exp_inf_wrapper("IC",{"seed_set":None, "innoculated":None, "c":.4},trials=5)
  # ADV_LT = exp_inf_wrapper("ADV_LT",{"seed_set":None, "adv_set":None, "r_threshold":.3, "type":"relative"},trials=1)
  # ADV_UC = exp_inf_wrapper("ADV_UC",{"seed_set":None, "adv_set":None, "c":.8},trials=5)
  
  # test_processes = [UC,IC,LT,EM_IC,ADV_LT,ADV_UC]
  
  # Test all graphs / all processes
  # for key in all_graphs:  
    # for key2 in all_graphs[key]:
      # test_graph = all_graphs[key][key2] 
      # for i in range(len(test_processes)):
        # tprocess = test_processes[i]
        # seed = r.sample(range(test_graph.N),5)
        # try:
          # tprocess(seed,test_graph)
        # except Exception as e:
          # print(i,key,key2)
          # print(traceback.format_exc())
        
  ## EXPERIMENTAL SECTION ##
  
  ## SETUP ##
      
  results_filename = "results_exp2_p2_EM_IC.p" 
  
  if ospath.exists(results_filename):
    with open(results_filename,"rb") as f:
      results = pickle.load(f)
  else:
    results = {}
      
  process_params = [.25, .5, 1, 2]
  algs = ["greed","GA","rand","top_k"]
  ks = [2,4,6,8,10,12,14]
  saved_seeds = {}
  IC_trials = 5
  
  # for key in results:
    # print(key,results[key])
  
  tt = time.time()
  ts,te = [tt,tt]
  for p_param in process_params:
    
      for g_type in all_graphs:  
        for g_param in all_graphs[g_type]:
          graph = all_graphs[g_type][g_param] 
          avg_deg = graph.M / graph.N
          c = p_param / avg_deg
          
          #IC = exp_inf_wrapper("IC",{"seed_set":None, "c":c},trials=IC_trials)
          EM_IC = exp_inf_wrapper("IC",{"seed_set":None, "innoculated":None, "c":c},trials=10)
          EM_IC_res = exp_inf_wrapper("IC",{"seed_set":None, "innoculated":None, "c":c},trials=100)
        
          print(p_param,g_type,g_param,"total",round(ts-tt,1),"last:",round(te-ts,1))
          #print(np.argwhere(graph.temp["EM_seed"]==1).T[0])
          ts = time.time()
            
          if ("EM_IC",p_param,g_type,g_param,"GA_P",ks[-1]) in results:
            continue
            
          else:
            try:
              ## EM IC ##
                  
              # # Greedy
              # s = time.time()
              # res = gg.greedy(graph,EM_IC,ks,submodular=False)
              # e = time.time()
                
              # etime = e-s
              # evals = res[1]
              # for k_ind in range(len(ks)):
                # exp_inf = EM_IC_res(res[0][k_ind],graph)
                # results["EM_IC",p_param,g_type,g_param,"greedy",ks[k_ind]] = exp_inf
              # results["EM_IC",p_param,g_type,g_param,"greedy","t"] = etime
              # results["EM_IC",p_param,g_type,g_param,"greedy","evals"] = evals

              # for k in ks:
                # # GA
                # s = time.time()
                # ga = sga.K_graph_GA(graph,graph.IC,{"seed_set":None, "innoculated":None, "c":c},
                  # trials=10,k=k,early_stop=True)
                # res = ga()
                # e = time.time()
                  
                # etime = e-s
                # evals = res[1][-1]
                # exp_inf = EM_IC_res(res[0][0],graph)
                # if k == ks[-1]: # only storing the time / evals for largest K
                  # results["EM_IC",p_param,g_type,g_param,"GA","t"] = etime
                  # results["EM_IC",p_param,g_type,g_param,"GA","evals"] = evals
                  
                # results["EM_IC",p_param,g_type,g_param,"GA",k] = exp_inf
                  
                # #Top btwn
                
                # top = temp_grab(graph,"top"+str(k),top_K,[graph,nx.betweenness_centrality,k])
                # exp_inf = EM_IC_res(top,graph)
                # results["EM_IC",p_param,g_type,g_param,"top_k",k] = exp_inf
                    
                # # Rand
                # rand = r.sample(range(graph.N),k)
                # exp_inf = EM_IC_res(rand,graph)
                # results["EM_IC",p_param,g_type,g_param,"rand",k] = exp_inf

              for k in ks:
                # GA
                s = time.time()
                pool_size = int(g_param[1] / 5)
                
                if pool_size == 100:
                  if k == ks[-1]: # only storing the time / evals for largest K
                    results["EM_IC",p_param,g_type,g_param,"GA_P","t"] = results["EM_IC",p_param,g_type,g_param,"GA","t"]
                    results["EM_IC",p_param,g_type,g_param,"GA_P","evals"] = results["EM_IC",p_param,g_type,g_param,"GA","evals"]
                  results["EM_IC",p_param,g_type,g_param,"GA_P",k] = results["EM_IC",p_param,g_type,g_param,"GA",k]
                
                else:
                  GA_params={"pr_mutate":.8,"iterations":100,"pool_size":pool_size,"tournament_size":2}
                  ga = sga.K_graph_GA(graph,graph.IC,{"seed_set":None, "innoculated":None, "c":c},
                    trials=10,k=k,early_stop=True,GA_params=GA_params)
                  res = ga()
                  e = time.time()
                    
                  etime = e-s
                  evals = res[1][-1]
                  exp_inf = res[0][1]
                  if k == ks[-1]: # only storing the time / evals for largest K
                    results["EM_IC",p_param,g_type,g_param,"GA_P","t"] = etime
                    results["EM_IC",p_param,g_type,g_param,"GA_P","evals"] = evals
                    
                  results["EM_IC",p_param,g_type,g_param,"GA_P",k] = exp_inf
                
              with open(results_filename,"wb") as f:
                pickle.dump(results, f)
                    
            except Exception as e:
              print("Failed to conduct eval:",p_param,g_type,g_param)
              print(traceback.format_exc())
        
          te = time.time()


def temp_grab(graph,key,fun,params,overwrite=False):
  
  if key in graph.temp and not overwrite:
    return graph.temp[key]
    
  store = list(fun(*params))
  seed_set = np.zeros(graph.N)
  seed_set[store] = 1  
  #print(seed_set)
    
  graph.temp["key"] = seed_set
  return graph.temp["key"]
  
def exp_inf_wrapper(process,process_params,trials=1):

  def exp_inf(ind,graph):
  
    processes = {"LT":graph.LT, "IC":graph.IC, "UC":graph.UC, "CC":graph.CC,
      "ADV_UC":graph.ADV_UC, "ADV_LT":graph.ADV_LT}
      
    g_process = processes[process]
    
    if type(ind) == list or type(ind) == set:
      individual = list(ind)
      seed_set = np.zeros(graph.N)
      seed_set[individual] = 1
    else:
      seed_set = np.copy(ind)
        
    if "innoculated" in process_params:
      process_params["innoculated"] = seed_set
      process_params["seed_set"] = graph.temp["EM_seed"]
    else:  
      if "adv_set" in process_params:
        process_params["adv_set"] = graph.temp["adv_set",process]
      process_params["seed_set"] = seed_set
    
    sum_infected = 0
    for x in range(trials):
      sum_infected += g_process(**process_params)[0]
    
    avg_inf = sum_infected / trials
    
    return avg_inf  
    
  return exp_inf
  
def deg(graph,i):
  return np.sum(graph.adj_mat[i])
  
def top_K(graph,fun,k):
  
  dict = fun(graph.nxgraph)
  #dict = {i:fun(graph,i) for i in range(graph.N)}
  sorted_d = sorted(dict, key=dict.get, reverse=True)
  topk = set(sorted_d[0:k])
  return topk
  

def avg_IC(graph,individual,c,trials):

  sum_infected = 0
  seed_set = np.zeros(graph.N)
  seed_set[individual] = 1
  process_params = {"seed_set":seed_set, "c":c}
  for x in range(trials):
    sum_infected += graph.IC(**process_params)[0]
  
  return sum_infected / trials

def gen_param_masks(x_keys,param_masks=[]):
  
  if len(x_keys) == 0:
    return param_masks
  top = x_keys[0]
  index = top[0]
  remainder = x_keys[1:]
  new_masks = []
  for kv in top[1:]:
    for param_mask in param_masks:
      new_mask = param_mask.copy()
      new_mask[index] = kv
      new_masks.append(new_mask)

  return gen_param_masks(remainder,new_masks)
  
def get_matching_data(results, pmask):
  
  keys = results.keys()
  matched_data = []
  for key in keys:
    if pmask[2] == "SP" and key[0] == "N":
      pmask[2] = "DP"
    elif pmask[2] == "DP" and key[0] == "K":
      pmask[2] = "SP"
      
    matches = [pmask[i] == key[i] or pmask[i]=="*" for i in range(len(pmask))]
    if False not in matches:
      matched_data.append(results[key])
  return matched_data
  
def add_matching_dict(original, pmask, trimmed_dict):
  
  keys = original.keys()
  for key in keys:
    if pmask[2] == "SP" and key[0] == "N":
      pmask[2] = "DP"
    elif pmask[2] == "DP" and key[0] == "K":
      pmask[2] = "SP"
      
    matches = [pmask[i] == key[i] or pmask[i]=="*" for i in range(len(pmask))]
    if False not in matches:
      trimmed_dict[key] = original[key]
  
def box_whisker(results, y_var, x_keys, base_mask_keys=None, func=None, y_axis="Y Default", title="Default"):

  labels = ["Rep:","Mut:","Cross:","Graph:","Process:","Deg Wtd:","Seed Size:"]

  base_masks = [["*","*","*","*","*","*","*",y_var]]
  pmasks = gen_param_masks(x_keys,param_masks=base_masks)
  
  if base_mask_keys != None:
    trimmed_dict = {}
    base_masks = gen_param_masks(base_mask_keys,base_masks)
    
    for bmask in base_masks:
      add_matching_dict(results,bmask,trimmed_dict)
  else:
    trimmed_dict = results.copy()

  data_sets = []
  for pmask in pmasks:
    data_set = get_matching_data(trimmed_dict,pmask)
    if func != None:
      data_set = [func(datum) for datum in data_set]
    data_sets.append(data_set)
    
  labels = []
  for i in range(len(pmasks)):
    labels.append(pmask_to_label(pmasks[i]))
  
  fig1, ax1 = plt.subplots()
  ax1.set_title(title)
  ax1.boxplot(data_sets,labels=labels)
  plt.xticks(rotation=90)
  ax1.set_ylabel(y_axis)
  plt.tight_layout()
  plt.show()
  
  
def relative_box_whisker(results, y_var, x_keys, base_mask_keys=None, func=None, y_axis="Y Default", title="Default"):

  labels = ["Rep:","Mut:","Cross:","Graph:","Process:","Deg Wtd:","Seed Size:"]

  base_masks = [["*","*","*","*","*","*","*",y_var]]
  pmasks = gen_param_masks(x_keys,param_masks=base_masks)
  
  if base_mask_keys != None:
    trimmed_dict = {}
    base_masks = gen_param_masks(base_mask_keys,base_masks)
    
    for bmask in base_masks:
      add_matching_dict(results,bmask,trimmed_dict)
  else:
    trimmed_dict = results.copy()
    
  data_sets = [[] for i in range(len(pmasks))]
  
  pmask1 = pmasks[0]
  keys_ordered = []
  for key in trimmed_dict:
    if pmask1[2] == "SP" and key[0] == "N":
      pmask1[2] = "DP"
    elif pmask1[2] == "DP" and key[0] == "K":
      pmask1[2] = "SP"
      
    matches = [pmask1[i] == key[i] or pmask1[i]=="*" for i in range(len(pmask1))]
    if False not in matches:
      data_sets[0].append(trimmed_dict[key])
      keys_ordered.append(key)
  
  for i in range(len(pmasks)-1):
    pmask = pmasks[i+1]

    for key in keys_ordered:
      temp_key = list(key)        
      temp_key = [pmask[i] if pmask[i] != "*" else temp_key[i] for i in range(len(pmask))]
      if temp_key[2] == "SP" and temp_key[0] == "N":
        temp_key[2] = "DP"
      elif temp_key[2] == "DP" and temp_key[0] == "K":
        temp_key[2] = "SP"
      temp_key = tuple(temp_key)
      data_sets[i+1].append(trimmed_dict[temp_key])
      
  if func != None:
    for i in range(len(data_sets)):
      data_sets[i] = [func(datum) for datum in data_sets[i]]
  
  data_sets = np.asarray(data_sets)
  data_sets = data_sets.astype(float)
  averages = np.average(data_sets,axis=0)
  data_sets -= averages

  labels = []
  for i in range(len(pmasks)):
    labels.append(pmask_to_label(pmasks[i]))
  
  fig1, ax1 = plt.subplots()
  ax1.set_title(title)
  ax1.boxplot(data_sets.T,labels=labels)
  plt.xticks(rotation=90)
  ax1.set_ylabel(y_axis)
  plt.tight_layout()
  plt.show()
   
def pmask_to_label(pmask):
  
  labels = ["R:","M:","C:","G:","P:","DW:","K:"]
  label = ""
  for i in range(len(pmask)-1):
    if pmask[i] != "*":
      label += labels[i] + str(pmask[i]) + ", "
  return label
        
def time_to_find(fitness_over_time):
  
  best = max(fitness_over_time)
  return np.argwhere(np.array(fitness_over_time) >= best*.99)[0][0]

# GA variant component functions

# N = Size of graph in nodes
# K = num of communities
# a = intra community link probability OR average intra community degree
# b = inter community link probability OR average inter community degree
def gen_sbm(N,K,a,b,probabilities=False):

  am = np.random.uniform(size=(N,N))
  C = int(N/K)
  
  if not probabilities:
    a = a/C
    b = b/(N-C)
 
  for r in range(K):
    for s in range(r+1):
      slice = am[r*C:(r+1)*C,s*C:(s+1)*C]
      if r == s:
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(slice < a, 1.0, 0.0)
      else:
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(slice < b, 1.0, 0.0)
  am = np.tril(am,-1) + np.tril(am,-1).T
  return eg.Experiment_Graph("sbm",am=am)
  
# N = Size of graph in nodes
# K = num of communities
# a = intra community link probability OR average intra community degree
# b = inter community link probability OR average inter community degree
def gen_dc_sbm(N,K,a,b,gamma,kmin,kmax,probabilities=False):

  am = np.random.uniform(size=(N,N))
  C = int(N/K)
  
  if not probabilities:
    a = a/C
    b = b/(N-C)
  
  #print(np.around(am,1))
  
  node_popularities = []
  for r in range(K):
    comm_degs = powerlaw_degrees(gamma,kmin,kmax,C)
    sum_deg = sum(comm_degs)
    node_popularities += [cd/sum_deg for cd in comm_degs]
    #alpha = (a*C)/sum(node_popularities)
  node_popularities = np.array(node_popularities)
  #node_popularities = node_popularities.reshape(1,N)
  #print(node_popularities)
  
  targets = np.outer(node_popularities,node_popularities)
  
  #print(np.around(am,1)) 
  C2 = C**2
 
  for r in range(K):
    for s in range(r+1):
      rand_slice = am[r*C:(r+1)*C,s*C:(s+1)*C]
      target_slice = targets[r*C:(r+1)*C,s*C:(s+1)*C]
      target_sum = np.sum(target_slice)
      if r == s:
        wrs_u = a*C2/target_sum
        target_slice *= wrs_u
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(rand_slice < target_slice, 1.0, 0.0)
      else:
        wrs_u = b*C2/target_sum
        target_slice *= wrs_u
        am[r*C:(r+1)*C,s*C:(s+1)*C] = np.where(rand_slice < target_slice, 1.0, 0.0)
  am = np.tril(am,-1) + np.tril(am,-1).T
  #print(np.around(am,1))
  return eg.Experiment_Graph("sbm",am=am)
  
  
def ba_graph(N,m):
  
  am = np.zeros((N,N))
  link_draw = m
  total = 0
  for n in range(1,N):
    if m%1 != 0.0:
      link_draw = 1 + np.random.poisson(m-1)

    links = int(min(n,link_draw))
    total += links
    probs = np.sum(am,axis=0)[0:n]
    if np.sum(probs) == 0:
      probs = np.ones(n) / n
    else:
      probs = probs / np.sum(probs)
    
    # np.arange non-inclusive,choice is by default non-replacement
    nbrs = np.random.choice(np.arange(n),size=links,replace=False,p=probs)
    # print(n,links,nbrs)

    # if n in nbrs or links != len(nbrs):
      # print("HERE")
    am[n,nbrs] = 1
    am[nbrs,n] = 1
    # print(am)
  
  name = "BA:" + str(N) + "," + str(m)
  new_ba = eg.Experiment_Graph(name,am=am)
  # print(total,np.sum(am))
  return new_ba
    

def sbm_gen_params(N,groups,avg_deg_intra,avg_deg_inter):

  sbm_membership = [int(i/(N/groups)) for i in range(N)]
  inter_edges = avg_deg_inter * (N / groups)
  intra_edges = 2 * avg_deg_intra * (N / groups)
  inter_comm_edges = np.full((groups,groups),inter_edges)
  np.fill_diagonal(inter_comm_edges,intra_edges)
  return [sbm_membership, inter_comm_edges]
  
def powerlaw_degrees(gamma,kmin,kmax,N):
  pdf = np.array([x**-gamma for x in range(kmin,kmax+1)])
  pdf = pdf / np.sum(pdf)
  return np.random.choice(range(kmin,kmax+1),size=N,p=pdf)
  
if __name__ == "__main__":
  main()

