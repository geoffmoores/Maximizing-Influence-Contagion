@inproceedings{nr,
     title={The Network Data Repository with Interactive Graph Analytics and Visualization},
     author={Ryan A. Rossi and Nesreen K. Ahmed},
     booktitle={AAAI},
     url={http://networkrepository.com},
     year={2015}
}

@article{jeong2001lethality,
     title={Lethality and centrality in protein networks},
     author={Jeong, H. and Mason, S.P. and Barabasi, A.L. and Oltvai, Z.N.},
     journal={arXiv preprint cond-mat/0105306},
     year={2001}
}

@article{singh2008-isorank-multi,
     author = {Singh, Rohit and Xu, Jinbo and Berger, Bonnie},
     title = {Global alignment of multiple protein interaction networks with application to functional orthology detection},
     journal = {PNAS},
     year = {2008},
     volume = {105},
     pages = {12763-12768},
     number = {35}
}

@article{goh2007human,
     title={The human disease network},
     author={Goh, Kwang-Il and Cusick, Michael E and Valle, David and Childs, Barton and Vidal, Marc and Barab{\'a}si,
Albert-L{\'a}szl{\'o}
},
     journal={Proceedings of the National Academy of Sciences},
     volume={104},
     number={21},
     pages={8685--8690},
     year={2007},
     publisher={National Acad Sciences}
}

@article{duch2005community,
     title={Community identification using Extremal Optimization Phys},
     author={Duch, J. and Arenas, A.},
     journal={Rev. E},
     volume={72},
     pages={027104},
     year={2005}
}

@article{cho2014wormnet,
     title={WormNet v3: a network-assisted hypothesis-generating server for Caenorhabditis elegans},
     author={Cho, Ara and Shin, Junha and Hwang, Sohyun and Kim, Chanyoung and Shim, Hongseok and Kim, Hyojin and Kim, Hanhae and Lee, Insuk},
     journal={Nucleic acids research},
     volume={42},
     number={W1},
     pages={W76--W82},
     year={2014},
     publisher={Oxford University Press}
}

@article {bigbrain,
     author = {Amunts, Katrin and Lepage, Claude and Borgeat, Louis and Mohlberg, Hartmut and Dickscheid, Timo and Rousseau, Marc-{\'E}tienne and Bludau,
Sebastian and Bazin, Pierre-Louis and Lewis, Lindsay B. and Oros-Peusquens, Ana-Maria and Shah, Nadim J. and Lippert, Thomas and Zilles, Karl and Evans, Alan C.},
     title = {BigBrain: An Ultrahigh-Resolution 3D Human Brain Model},
     volume = {340},
     number = {6139},
     pages = {1472--1475},
     year = {2013},
     publisher = {AAAS},
     journal = {Science}
}

@article {bigbrain,
     author = {Amunts, Katrin and Lepage, Claude and Borgeat, Louis and Mohlberg, Hartmut and Dickscheid, Timo and Rousseau, Marc-{\'E}tienne and Bludau,
Sebastian and Bazin, Pierre-Louis and Lewis, Lindsay B. and Oros-Peusquens, Ana-Maria and Shah, Nadim J. and Lippert, Thomas and Zilles, Karl and Evans, Alan C.},
     title = {BigBrain: An Ultrahigh-Resolution 3D Human Brain Model},
     volume = {340},
     number = {6139},
     pages = {1472--1475},
     year = {2013},
     publisher = {AAAS},
     journal = {Science}
}

@book{de2011exploratory,
     title={Exploratory social network analysis with Pajek},
     author={De Nooy, Wouter and Mrvar, Andrej and Batagelj, Vladimir},
     volume={27},
     year={2011},
     publisher={Cambridge University Press}
}

@article{batagelj2000some,
     title={Some analyses of Erdos collaboration graph},
     author={Batagelj, Vladimir and Mrvar, Andrej},
     journal={Social Networks},
     volume={22},
     number={2},
     pages={173--186},
     year={2000},
     publisher={Elsevier}
}

@article{ulanowicz1998network,
     title={Network analysis of trophic dynamics in south florida ecosystems},
     author={Ulanowicz, Robert E and DeAngelis, Donald L},
     journal={FY97: The Florida Bay Ecosystem},
     pages={20688--20038},
     year={1998}
}

@article{melian2004food,
     title={Food web cohesion},
     author={Meli{\'a}n,
Carlos J and Bascompte, Jordi},
     journal={Ecology},
     volume={85},
     number={2},
     pages={352--358},
     year={2004},
     publisher={Eco Soc America}
}

@article{escortsRocha2010,
     author = {Rocha, Luis E. C. and Liljeros, Fredrik and Holme, Petter},
     journal = {Proc. of the National Academy of Sciences},
     number = 13,      pages = {5706--5711},
     title = {Information Dynamics Shape the Sexual Networks of {Internet}-mediated Prostitution},
     volume = 107,      year = 2010}

@misc{infect,
     author={{SocioPatterns}},
     title={Infectious contact networks},
     note={http://www.sociopatterns.org/datasets/. Accessed 09/12/12.}}

@article{opsahl2009clustering,
     title={Clustering in weighted networks},
     author={Opsahl, T. and Panzarasa, P.},
     journal={Social networks},
     volume={31},
     number={2},
     pages={155--163},
     year={2009},
     publisher={Elsevier}
}

@misc{infect,
     author={{SocioPatterns}},
     title={Infectious contact networks},
     note={http://www.sociopatterns.org/datasets/. Accessed 09/12/12.}}
     
@Description:This dataset contains the temporal network of contacts between patients,
patients and health-care workers (HCWs) and among HCWs in a hospital ward in Lyon, F

@article{rossi2012fastclique,
     title={What if CLIQUE were fast? Maximum Cliques in Information Networks and Strong Components in Temporal Networks},
     author={Ryan A. Rossi and David F. Gleich and Assefaw H. Gebremedhin and Mostofa A. Patwary},
     journal={arXiv preprint arXiv:1210.5802},
     pages={1--11},
     year={2012}
}

@inproceedings{rossi2014pmc-www,
     title={Fast Maximum Clique Algorithms for Large Graphs},
     author={Ryan A. Rossi and David F. Gleich and Assefaw H. Gebremedhin and Mostofa A. Patwary},
     booktitle={Proceedings of the 23rd International Conference on World Wide Web (WWW)},
     year={2014}
}

@misc{truthy,
     author={{Truthy}},
     title={Information Diffusion Research at Indiana University},
     note={{\url{http://truthy.indiana.edu/}}. Accessed 10/20/12.}}
     
@inproceedings{rozemberczki2019gemsec,
     title={GEMSEC: Graph Embedding with Self Clustering},
     author={Rozemberczki, Benedek and Davies, Ryan and Sarkar, Rik and Sutton, Charles},
     booktitle={Proceedings of the 2019 IEEE/ACM International Conference on Advances in Social Networks Analysis and Mining 2019},
     pages={65-72},
     year={2019},
     organization={ACM}
}

@article{Fire2012,
     title={Link Prediction in Highly Fractional Data Sets},
     author={Fire, M., and Puzis, R., and Elovici, Y. },
     journal={Handbook of Computational Approaches to Counterterrorism},
     year={2012}publisher={Springer}
}

@article{read1954cultures,
     title={Cultures of the central highlands, New Guinea},
     author={Read, Kenneth E},
     journal={Southwestern Journal of Anthropology},
     pages={1--43},
     year={1954},
     publisher={JSTOR}
}

@article{zachary1977information,
     title={An information flow model for conflict and fission in small groups},
     author={Zachary, Wayne W},
     journal={Journal of anthropological research},
     pages={452--473},
     year={1977},
     publisher={JSTOR}
}

@article{lusseau2003bottlenose,
     title={The bottlenose dolphin community of Doubtful Sound features a large proportion of long-lasting associations},
     author={Lusseau, David and Schneider, Karsten and Boisseau, Oliver J and Haase, Patti and Slooten, Elisabeth and Dawson, Steve M},
     journal={Behavioral Ecology and Sociobiology},
     volume={54},
     number={4},
     pages={396--405},
     year={2003},
     publisher={Springer}
}

@inproceedings{leskovec2010signed,
     title={Signed networks in social media},
     author={Leskovec, Jure and Huttenlocher, Daniel and Kleinberg, Jon},
     booktitle={Proceedings of the SIGCHI Conference on Human Factors in Computing Systems},
     pages={1361--1370},
     year={2010},
     organization={ACM}
}

@misc{soc-hamsterster,
     author={Hamsterster},
     title={Hamsterster social network},
     note={http://www.hamsterster.com}
}

@inproceedings{massa2009bowling,
     title={Bowling alone and trust decline in social network sites},
     author={Massa, Paolo and Salvetti, Martino and Tomasoni, Danilo},
     booktitle={Dependable, Autonomic and Secure Computing, 2009. DASC'09. Eighth IEEE International Conference on},
     pages={658--663},
     year={2009},
     organization={IEEE}
}

@article{traud2012social,
     title={Social structure of {F}acebook networks},
     author={Traud, Amanda L and Mucha, Peter J and Porter, Mason A},
     journal={Phys. A},
     month={Aug},
     number={16},
     pages={4165--4180},
     volume={391},
     year={2012}
}

@article{Traud:2011fs,
     title={Comparing Community Structure to Characteristics in Online Collegiate Social Networks},
     author={Traud, Amanda L and Kelsic, Eric D and Mucha, Peter J and Porter, Mason A},
     journal={SIAM Rev.},
     number={3},
     pages={526--543},
     volume={53},
     year={2011}
}

@article{mahadevan2006internet,
     title={The Internet AS-level topology: three data sources and one definitive metric},
     author={Mahadevan, P. and Krioukov, D. and Fomenkov, M. and Dimitropoulos, X. and Vahdat, A. and others},
     journal={SIGCOMM},
     volume={36},
     number={1},
     pages={17--26},
     year={2006},
}

@misc{whois,
     author={{WHOIS}},
     title={{Internet} Routing Registries},
     note={{\scriptsize \url{http://www.irr.net/}}}}

@misc{routeviews,
     author={{Internet-AS}},
     title={{Oregon RouteViews} Project},
     note={{\scriptsize \url{http://www.routeviews.org/}}}}

@inproceedings{rossi2013topology,
     title={A Multi-Level Approach for Evaluating Internet Topology Generators},
     author={Ryan A. Rossi and Sonia Fahmy and Nilothpal Talukder},
     booktitle={Networking},
     pages={1--9},
     year={2013}
}

@article{boguna2004models,
     title={Models of social networks based on social distance attachment},
     author={Bogu{\~n}{\'a},
Mari{\'a}n and Pastor-Satorras,
Romualdo and D{\'\i}az-Guilera,
Albert and Arenas, Alex},
     journal={Physical Review E},
     volume={70},
     number={5},
     pages={056122},
     year={2004},
     publisher={APS}
}

@inproceedings{rocketfuel,
     title={Measuring {ISP} topologies with Rocketfuel},
     author={Spring, N. and Mahajan, R. and Wetherall, D.},
     booktitle={SIGCOMM},
     volume={32},
     number={4},
     pages={133--145},
     year={2002}
}

@inproceedings{adamic2005political,
     title={The political blogosphere and the 2004 US election: divided they blog},
     author={Adamic, Lada A and Glance, Natalie},
     booktitle={Proceedings of the 3rd international workshop on Link discovery},
     pages={36--43},
     year={2005},
     organization={ACM}
}

@article{gleich2004fast,
     title={Fast parallel PageRank: A linear system approach},
     author={Gleich, David and Zhukov, Leonid and Berkhin, Pavel},
     journal={Yahoo! Research Technical Report YRL-2004-038},
     volume={13},
     pages={22},
     year={2004}
}

@book{de2011exploratory,
     title={Exploratory social network analysis with Pajek},
     author={De Nooy, Wouter and Mrvar, Andrej and Batagelj, Vladimir},
     volume={27},
     year={2011},
     publisher={Cambridge University Press}
}

@ARTICLE{boldi2004-ubicrawler,
     author = {Paolo Boldi and Bruno Codenotti and Massimo Santini and Sebastiano Vigna},
     title = {{UbiCrawler}: A Scalable Fully Distributed Web Crawler},
     journal = {Software: Practice \& Experience},
     year = {2004},
     volume = {34},
     pages = {711--726},
     number = {8}}

@INPROCEEDINGS{Boldi-2011-layered,
     author = {Paolo Boldi and Marco Rosa and Massimo Santini and Sebastiano Vigna},
     title = {Layered Label Propagation: A MultiResolution Coordinate-Free Ordering for Compressing Social Networks},
     booktitle = {WWW},
     year = {2011},
     pages = {587--596}
}

@inproceedings{castillo2008web,
     title={Web spam challenge 2008},
     author={Castillo, Carlos and Chellapilla, Kumar and Denoyer, Ludovic},
     booktitle={Proceedings of the 4th International Workshop on Adversarial Information Retrieval on the Web (AIRWeb)},
     year={2008}
}
